/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo, useEffect, useCallback, useRef } from 'react';
import * as XLSX from 'xlsx';
import { Header } from './components/Header';
import { StatsBar } from './components/StatsBar';
import { DriveSyncBar } from './components/DriveSyncBar';
import { FileUploader } from './components/FileUploader';
import { DateFilterBar } from './components/DateFilterBar';
import { ViewModeBar } from './components/ViewModeBar';
import { MessageFeed } from './components/MessageFeed';
import { NotificationTable } from './components/NotificationTable';
import { MessagePreviewModal } from './components/MessagePreviewModal';
import { AutoDispatcherModal } from './components/AutoDispatcherModal';
import { StickyBottomBar } from './components/StickyBottomBar';
import { PythonScriptModal } from './components/PythonScriptModal';
import { GoogleDriveModal } from './components/GoogleDriveModal';
import { SAMPLE_EXCEL_ROWS } from './data/sampleData';
import { initAuth, getAccessToken, AuthUser } from './services/googleAuth';
import {
  downloadDriveFile,
  checkDriveFileMeta,
  DriveFileItem,
  playNotificationChime,
} from './services/googleDrive';
import {
  ColumnMapping,
  ProcessedNotification,
  extractRowNotification,
  deduplicateNotifications,
  detectColumns,
} from './utils/excelParser';

const SAVED_DRIVE_KEY = 'ais_saved_drive_file_config';

interface SavedDriveFile {
  id: string;
  name: string;
  mimeType: string;
  lastModifiedTime: string;
}

export default function App() {
  // 1. Core Data State
  const [rawRows, setRawRows] = useState<Record<string, any>[]>(SAMPLE_EXCEL_ROWS);
  const [fileName, setFileName] = useState<string>('حنححخه.xlsx (بيانات نموذجية)');
  const [columnMapping, setColumnMapping] = useState<ColumnMapping>({
    phoneCol: 'المستلم',
    msgCol: 'الرسالة',
    timeCol: 'الوقت',
  });
  const [countryCode, setCountryCode] = useState<string>('967');

  // 2. Google Drive Integration & Sync State
  const [currentUser, setCurrentUser] = useState<AuthUser | null>(null);
  const [accessToken, setAccessToken] = useState<string | null>(null);
  const [isDriveModalOpen, setIsDriveModalOpen] = useState(false);
  const [boundDriveFile, setBoundDriveFile] = useState<SavedDriveFile | null>(() => {
    try {
      const saved = localStorage.getItem(SAVED_DRIVE_KEY);
      return saved ? JSON.parse(saved) : null;
    } catch {
      return null;
    }
  });
  const [isSyncing, setIsSyncing] = useState(false);
  const [lastSyncTime, setLastSyncTime] = useState<Date | null>(null);
  const [autoSyncEnabled, setAutoSyncEnabled] = useState(true);
  const [newNotificationsCount, setNewNotificationsCount] = useState(0);

  // 3. Deduplication Setting ('phone_and_msg' | 'phone_only' | 'none')
  const [dedupMode, setDedupMode] = useState<'phone_and_msg' | 'phone_only' | 'none'>('phone_and_msg');

  // 4. View Mode State ('feed' = Cards stacked for vertical scrolling, 'table' = spreadsheet grid)
  const [viewMode, setViewMode] = useState<'feed' | 'table'>('feed');

  // 5. Selection State
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [copiedPhones, setCopiedPhones] = useState(false);

  // 6. Strict Date & Filter State
  const [selectedDate, setSelectedDate] = useState<string>('2026-09-29');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'unsent' | 'sent_wa' | 'sent_sms'>('all');

  // 7. Channel Sent Status Map (Tracking WhatsApp & SMS separately for each notification)
  const [channelStatusMap, setChannelStatusMap] = useState<
    Record<string, { whatsapp: boolean; sms: boolean }>
  >({});

  // 8. Modals State
  const [previewNotification, setPreviewNotification] = useState<ProcessedNotification | null>(null);
  const [isAutoDispatcherOpen, setIsAutoDispatcherOpen] = useState(false);
  const [batchChannel, setBatchChannel] = useState<'whatsapp' | 'sms'>('whatsapp');
  const [isPythonModalOpen, setIsPythonModalOpen] = useState(false);

  // Reference to current row count for detecting incoming updates
  const rawRowsLengthRef = useRef(rawRows.length);
  useEffect(() => {
    rawRowsLengthRef.current = rawRows.length;
  }, [rawRows.length]);

  // Initialize Firebase Auth listener
  useEffect(() => {
    const unsubscribe = initAuth(
      (user, token) => {
        setCurrentUser(user);
        setAccessToken(token);
      },
      () => {
        setCurrentUser(null);
        setAccessToken(null);
      }
    );
    return () => unsubscribe();
  }, []);

  // Request browser desktop notification permission
  useEffect(() => {
    if ('Notification' in window && Notification.permission === 'default') {
      Notification.requestPermission().catch(() => {});
    }
  }, []);

  // Sync / Download a specific Drive file
  const performDriveSync = useCallback(
    async (file: SavedDriveFile, token: string, isManual = false) => {
      setIsSyncing(true);
      try {
        const { buffer, modifiedTime, name } = await downloadDriveFile(
          file.id,
          file.mimeType,
          token
        );

        const workbook = XLSX.read(buffer, { type: 'array', cellDates: true });
        const firstSheetName = workbook.SheetNames[0];
        if (!firstSheetName) {
          throw new Error('الملف لا يحتوي على أوراق عمل صالحة');
        }

        const worksheet = workbook.Sheets[firstSheetName];
        const jsonData = XLSX.utils.sheet_to_json<Record<string, any>>(worksheet, { defval: '' });

        if (jsonData.length > 0) {
          const detected = detectColumns(Object.keys(jsonData[0]));
          setColumnMapping(detected);

          // Check if new notifications were added compared to previous
          const previousCount = rawRowsLengthRef.current;
          const currentCount = jsonData.length;
          const diff = currentCount - previousCount;

          if (diff > 0 && previousCount > 0) {
            setNewNotificationsCount(diff);
            playNotificationChime();

            // Native browser notification
            if ('Notification' in window && Notification.permission === 'granted') {
              new Notification('🔔 إشعار جديد من Google Drive', {
                body: `وصلت ${diff} إشعار جديد في ملف ${name} وتمت مزامنتها تلقائياً.`,
                icon: '/favicon.ico',
              });
            }
          }

          setRawRows(jsonData);
          setFileName(`${name} (Google Drive)`);

          // Auto-select date from first valid row
          const firstItem = extractRowNotification(jsonData[0] || {}, 0, detected, countryCode);
          if (firstItem.targetDate) {
            setSelectedDate(firstItem.targetDate);
          }

          // Update saved file metadata in state & localStorage
          const updatedConfig: SavedDriveFile = {
            id: file.id,
            name: name,
            mimeType: file.mimeType,
            lastModifiedTime: modifiedTime,
          };
          setBoundDriveFile(updatedConfig);
          localStorage.setItem(SAVED_DRIVE_KEY, JSON.stringify(updatedConfig));
        }

        setLastSyncTime(new Date());
      } catch (err: any) {
        console.error('Drive Sync Error:', err);
      } finally {
        setIsSyncing(false);
      }
    },
    [countryCode]
  );

  // Handle selecting a file from Drive modal
  const handleDriveFileSelected = (file: DriveFileItem) => {
    const config: SavedDriveFile = {
      id: file.id,
      name: file.name,
      mimeType: file.mimeType,
      lastModifiedTime: file.modifiedTime || '',
    };
    setBoundDriveFile(config);
    localStorage.setItem(SAVED_DRIVE_KEY, JSON.stringify(config));

    if (accessToken) {
      performDriveSync(config, accessToken, true);
    }
  };

  // Initial sync when auth becomes ready and bound file is stored
  useEffect(() => {
    if (accessToken && boundDriveFile && lastSyncTime === null) {
      performDriveSync(boundDriveFile, accessToken, false);
    }
  }, [accessToken, boundDriveFile, lastSyncTime, performDriveSync]);

  // Periodic Auto-Sync Timer (checks Google Drive file metadata every 30 seconds)
  useEffect(() => {
    if (!autoSyncEnabled || !boundDriveFile || !accessToken) return;

    const interval = setInterval(async () => {
      try {
        const meta = await checkDriveFileMeta(boundDriveFile.id, accessToken);
        // If file modifiedTime has changed on Drive, fetch updated content
        if (meta.modifiedTime && meta.modifiedTime !== boundDriveFile.lastModifiedTime) {
          await performDriveSync(
            {
              ...boundDriveFile,
              name: meta.name || boundDriveFile.name,
              lastModifiedTime: meta.modifiedTime,
            },
            accessToken,
            false
          );
        } else {
          setLastSyncTime(new Date());
        }
      } catch (err) {
        // Silently catch network transient errors in background check
      }
    }, 30000); // 30 seconds interval

    return () => clearInterval(interval);
  }, [autoSyncEnabled, boundDriveFile, accessToken, performDriveSync]);

  // Available headers in current dataset
  const availableHeaders = useMemo(() => {
    if (rawRows.length === 0) return [];
    return Object.keys(rawRows[0] || {});
  }, [rawRows]);

  // Step 1: Process all rows through the parser, surrogate emoji cleaner, and channel status
  const allNotifications: ProcessedNotification[] = useMemo(() => {
    return rawRows.map((row, index) => {
      const item = extractRowNotification(row, index, columnMapping, countryCode);
      const chStatus = channelStatusMap[item.id];
      if (chStatus) {
        item.whatsappSent = chStatus.whatsapp;
        item.smsSent = chStatus.sms;
        item.status = chStatus.whatsapp || chStatus.sms ? 'sent' : 'unsent';
      }
      return item;
    });
  }, [rawRows, columnMapping, countryCode, channelStatusMap]);

  // Step 2: Compute available dates with item counts in the uploaded sheet
  const availableDates = useMemo(() => {
    const counts: Record<string, number> = {};
    for (const item of allNotifications) {
      if (item.targetDate) {
        counts[item.targetDate] = (counts[item.targetDate] || 0) + 1;
      }
    }
    return Object.entries(counts)
      .map(([date, count]) => ({ date, count }))
      .sort((a, b) => b.date.localeCompare(a.date));
  }, [allNotifications]);

  // Step 3: Strictly isolate the selected date from the current sheet
  const dateStrictItems = useMemo(() => {
    if (!selectedDate) return allNotifications;
    return allNotifications.filter((item) => item.targetDate === selectedDate);
  }, [allNotifications, selectedDate]);

  // Step 4: Apply Deduplication to eliminate repeated notifications
  const { unique: dedupedItems, duplicateCount } = useMemo(() => {
    if (dedupMode === 'none') {
      return { unique: dateStrictItems, duplicateCount: 0 };
    }
    return deduplicateNotifications(dateStrictItems, dedupMode);
  }, [dateStrictItems, dedupMode]);

  // Step 5: Filter by search and channel sent status
  const filteredNotifications = useMemo(() => {
    return dedupedItems.filter((item) => {
      // Channel status filter
      if (statusFilter === 'unsent' && (item.whatsappSent || item.smsSent)) {
        return false;
      }
      if (statusFilter === 'sent_wa' && !item.whatsappSent) {
        return false;
      }
      if (statusFilter === 'sent_sms' && !item.smsSent) {
        return false;
      }

      // Live search filter
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase().trim();
        const matchesClient = item.clientName.toLowerCase().includes(q);
        const matchesPhone = item.phone.includes(q) || item.phoneFull.includes(q);
        const matchesMsg = item.rawMsg.toLowerCase().includes(q);
        const matchesTotal = item.totalAccount.toLowerCase().includes(q);
        return matchesClient || matchesPhone || matchesMsg || matchesTotal;
      }

      return true;
    });
  }, [dedupedItems, statusFilter, searchQuery]);

  // Auto-select all displayed items whenever date, dedup, or filters change
  useEffect(() => {
    const allFilteredIds = new Set(filteredNotifications.map((n) => n.id));
    setSelectedIds(allFilteredIds);
  }, [filteredNotifications.length, selectedDate, statusFilter, dedupMode]);

  // Key stats
  const totalInFile = allNotifications.length;
  const totalForDate = dedupedItems.length;
  const whatsappSentCount = dedupedItems.filter((n) => n.whatsappSent).length;
  const smsSentCount = dedupedItems.filter((n) => n.smsSent).length;
  const unsentCount = dedupedItems.filter((n) => !n.whatsappSent && !n.smsSent).length;

  // Multi-Selection Handlers
  const handleToggleSelect = (id: string) => {
    setSelectedIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) {
        next.delete(id);
      } else {
        next.add(id);
      }
      return next;
    });
  };

  const handleSelectAll = () => {
    const allFilteredIds = new Set(filteredNotifications.map((n) => n.id));
    setSelectedIds(allFilteredIds);
  };

  const handleDeselectAll = () => {
    setSelectedIds(new Set());
  };

  // Actions
  const handleLoadSample = () => {
    setRawRows(SAMPLE_EXCEL_ROWS);
    setFileName('حنححخه.xlsx (بيانات نموذجية)');
    setColumnMapping({
      phoneCol: 'المستلم',
      msgCol: 'الرسالة',
      timeCol: 'الوقت',
    });
    setSelectedDate('2026-09-29');
    setSearchQuery('');
    setChannelStatusMap({});
  };

  const handleFileParsed = (
    data: Record<string, any>[],
    name: string,
    detectedMapping: ColumnMapping
  ) => {
    setRawRows(data);
    setFileName(name);
    setColumnMapping(detectedMapping);
    setChannelStatusMap({});

    // Auto-detect the primary date from first valid row and lock onto it
    let initialDate = '';
    for (let i = 0; i < Math.min(data.length, 10); i++) {
      const sampleItem = extractRowNotification(data[i] || {}, i, detectedMapping, countryCode);
      if (sampleItem.targetDate) {
        initialDate = sampleItem.targetDate;
        break;
      }
    }
    setSelectedDate(initialDate);
  };

  // Toggle specific channel status manually
  const handleToggleWhatsAppStatus = (id: string) => {
    setChannelStatusMap((prev) => {
      const current = prev[id] || { whatsapp: false, sms: false };
      return {
        ...prev,
        [id]: { ...current, whatsapp: !current.whatsapp },
      };
    });
  };

  const handleToggleSmsStatus = (id: string) => {
    setChannelStatusMap((prev) => {
      const current = prev[id] || { whatsapp: false, sms: false };
      return {
        ...prev,
        [id]: { ...current, sms: !current.sms },
      };
    });
  };

  // Individual WhatsApp Send
  const handleSingleSendWhatsApp = (item: ProcessedNotification) => {
    if (!item.waLink) return;
    window.open(item.waLink, '_blank', 'noopener,noreferrer');
    setChannelStatusMap((prev) => {
      const current = prev[item.id] || { whatsapp: false, sms: false };
      return {
        ...prev,
        [item.id]: { ...current, whatsapp: true },
      };
    });
  };

  // Individual SMS Send
  const handleSingleSendSms = (item: ProcessedNotification) => {
    if (!item.smsLink) return;
    window.open(item.smsLink, '_blank', 'noopener,noreferrer');
    setChannelStatusMap((prev) => {
      const current = prev[item.id] || { whatsapp: false, sms: false };
      return {
        ...prev,
        [item.id]: { ...current, sms: true },
      };
    });
  };

  // Batch Sequential Send: takes selected items (or all filtered if none checked)
  const notificationsForBatch = useMemo(() => {
    const selectedList = filteredNotifications.filter((n) => selectedIds.has(n.id));
    return selectedList.length > 0 ? selectedList : filteredNotifications;
  }, [filteredNotifications, selectedIds]);

  const handleStartBatchSend = (channel: 'whatsapp' | 'sms') => {
    setBatchChannel(channel);
    setIsAutoDispatcherOpen(true);
  };

  const handleBatchMarkSent = (id: string, channel: 'whatsapp' | 'sms') => {
    setChannelStatusMap((prev) => {
      const current = prev[id] || { whatsapp: false, sms: false };
      return {
        ...prev,
        [id]: {
          ...current,
          whatsapp: channel === 'whatsapp' ? true : current.whatsapp,
          sms: channel === 'sms' ? true : current.sms,
        },
      };
    });
  };

  const handleMarkAllWhatsAppSent = () => {
    setChannelStatusMap((prev) => {
      const next = { ...prev };
      for (const item of filteredNotifications) {
        const cur = next[item.id] || { whatsapp: false, sms: false };
        next[item.id] = { ...cur, whatsapp: true };
      }
      return next;
    });
  };

  const handleMarkAllSmsSent = () => {
    setChannelStatusMap((prev) => {
      const next = { ...prev };
      for (const item of filteredNotifications) {
        const cur = next[item.id] || { whatsapp: false, sms: false };
        next[item.id] = { ...cur, sms: true };
      }
      return next;
    });
  };

  const handleResetStatus = () => {
    setChannelStatusMap({});
  };

  const handleCopySelectedPhones = () => {
    const selectedList = filteredNotifications.filter((n) => selectedIds.has(n.id));
    const phones = selectedList.map((n) => n.phoneFull || n.phone).filter(Boolean);
    navigator.clipboard.writeText(phones.join('\n'));
    setCopiedPhones(true);
    setTimeout(() => setCopiedPhones(false), 2000);
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-sans text-slate-900 pb-24">
      {/* Top Bar Navigation */}
      <Header
        onLoadSample={handleLoadSample}
        onOpenPythonModal={() => setIsPythonModalOpen(true)}
        onOpenQueueModal={() => handleStartBatchSend('whatsapp')}
        onOpenDriveModal={() => setIsDriveModalOpen(true)}
        isDriveConnected={!!boundDriveFile && !!accessToken}
        boundFileName={boundDriveFile?.name || null}
        totalFilteredCount={filteredNotifications.length}
        unsentCount={unsentCount}
      />

      {/* Metadata Stats Bar with WhatsApp & SMS Counters */}
      <StatsBar
        totalInFile={totalInFile}
        totalForDate={totalForDate}
        whatsappSentCount={whatsappSentCount}
        smsSentCount={smsSentCount}
        unsentCount={unsentCount}
        duplicateCount={duplicateCount}
        selectedDate={selectedDate}
        fileName={fileName}
        isDeduplicationActive={dedupMode !== 'none'}
      />

      {/* Main Content Viewport */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 w-full space-y-5 flex-1">
        {/* Google Drive Live Sync & New Update Notification Banner */}
        <DriveSyncBar
          boundFileName={boundDriveFile?.name || null}
          boundFileId={boundDriveFile?.id || null}
          isSyncing={isSyncing}
          lastSyncTime={lastSyncTime}
          autoSyncEnabled={autoSyncEnabled}
          onToggleAutoSync={() => setAutoSyncEnabled(!autoSyncEnabled)}
          onManualSync={() => {
            if (boundDriveFile && accessToken) {
              performDriveSync(boundDriveFile, accessToken, true);
            } else {
              setIsDriveModalOpen(true);
            }
          }}
          onOpenDriveModal={() => setIsDriveModalOpen(true)}
          newNotificationsCount={newNotificationsCount}
          onClearNewAlert={() => setNewNotificationsCount(0)}
        />

        {/* Upload & Column Mapping Section */}
        <FileUploader
          onFileParsed={handleFileParsed}
          availableHeaders={availableHeaders}
          columnMapping={columnMapping}
          onMappingChange={setColumnMapping}
          countryCode={countryCode}
          onCountryCodeChange={setCountryCode}
          currentFileName={fileName}
        />

        {/* Strict Date, Deduplication & Channel Filters */}
        <DateFilterBar
          availableDates={availableDates}
          selectedDate={selectedDate}
          onSelectDate={setSelectedDate}
          searchQuery={searchQuery}
          onSearchChange={setSearchQuery}
          statusFilter={statusFilter}
          onStatusFilterChange={setStatusFilter}
          dedupMode={dedupMode}
          onDedupModeChange={setDedupMode}
          duplicateCount={duplicateCount}
        />

        {/* View Mode Switcher (Feed vs Table) + Select All Actions */}
        <ViewModeBar
          viewMode={viewMode}
          onViewModeChange={setViewMode}
          totalCount={filteredNotifications.length}
          selectedCount={filteredNotifications.filter((n) => selectedIds.has(n.id)).length}
          onSelectAll={handleSelectAll}
          onDeselectAll={handleDeselectAll}
          onStartBatchSend={handleStartBatchSend}
        />

        {/* Dynamic View: Cards Feed View (scroll down message by message) OR Table View */}
        {viewMode === 'feed' ? (
          <MessageFeed
            notifications={filteredNotifications}
            selectedIds={selectedIds}
            onToggleSelect={handleToggleSelect}
            onSelectAll={handleSelectAll}
            onDeselectAll={handleDeselectAll}
            onToggleWhatsAppStatus={handleToggleWhatsAppStatus}
            onToggleSmsStatus={handleToggleSmsStatus}
            onSingleSendWhatsApp={handleSingleSendWhatsApp}
            onSingleSendSms={handleSingleSendSms}
            onStartBatchSend={handleStartBatchSend}
          />
        ) : (
          <NotificationTable
            notifications={filteredNotifications}
            selectedDate={selectedDate}
            selectedIds={selectedIds}
            onToggleSelect={handleToggleSelect}
            onSelectAll={handleSelectAll}
            onDeselectAll={handleDeselectAll}
            onToggleWhatsAppStatus={handleToggleWhatsAppStatus}
            onToggleSmsStatus={handleToggleSmsStatus}
            onPreviewMessage={(n) => setPreviewNotification(n)}
            onMarkAllWhatsAppSent={handleMarkAllWhatsAppSent}
            onMarkAllSmsSent={handleMarkAllSmsSent}
            onResetStatus={handleResetStatus}
            onStartBatchSend={handleStartBatchSend}
            onSingleSendWhatsApp={handleSingleSendWhatsApp}
            onSingleSendSms={handleSingleSendSms}
          />
        )}
      </main>

      {/* Floating Sticky Bottom Bar when messages are selected */}
      <StickyBottomBar
        selectedCount={filteredNotifications.filter((n) => selectedIds.has(n.id)).length}
        totalCount={filteredNotifications.length}
        onStartBatchSend={handleStartBatchSend}
        onSelectAll={handleSelectAll}
        onDeselectAll={handleDeselectAll}
        onMarkSelectedWhatsAppSent={handleMarkAllWhatsAppSent}
        onMarkSelectedSmsSent={handleMarkAllSmsSent}
        onCopySelectedPhones={handleCopySelectedPhones}
        copiedPhones={copiedPhones}
      />

      {/* Message Preview Modal */}
      <MessagePreviewModal
        notification={previewNotification}
        onClose={() => setPreviewNotification(null)}
        onSent={(id) => {
          handleToggleWhatsAppStatus(id);
          setPreviewNotification(null);
        }}
      />

      {/* Sequential Batch Auto-Dispatcher Modal (WhatsApp & SMS) */}
      <AutoDispatcherModal
        notifications={notificationsForBatch}
        isOpen={isAutoDispatcherOpen}
        initialChannel={batchChannel}
        onClose={() => setIsAutoDispatcherOpen(false)}
        onMarkSent={handleBatchMarkSent}
      />

      {/* Google Drive File Browser & Selector Modal */}
      <GoogleDriveModal
        isOpen={isDriveModalOpen}
        onClose={() => setIsDriveModalOpen(false)}
        currentUser={currentUser}
        accessToken={accessToken}
        onAuthSuccess={(user, token) => {
          setCurrentUser(user);
          setAccessToken(token);
        }}
        onFileSelected={handleDriveFileSelected}
        selectedFileId={boundDriveFile?.id || null}
      />

      {/* Python Script Modal */}
      <PythonScriptModal
        isOpen={isPythonModalOpen}
        onClose={() => setIsPythonModalOpen(false)}
        fileName={fileName.split(' ')[0]}
        selectedDate={selectedDate}
        mapping={columnMapping}
        countryCode={countryCode}
      />
    </div>
  );
}
