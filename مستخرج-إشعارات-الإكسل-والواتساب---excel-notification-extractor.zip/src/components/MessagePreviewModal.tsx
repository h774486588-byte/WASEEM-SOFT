import React, { useState } from 'react';
import { X, Send, Copy, Check, MessageSquare, Phone, User, Calendar, ExternalLink } from 'lucide-react';
import { ProcessedNotification } from '../utils/excelParser';

interface MessagePreviewModalProps {
  notification: ProcessedNotification | null;
  onClose: () => void;
  onSent: (id: string) => void;
}

export const MessagePreviewModal: React.FC<MessagePreviewModalProps> = ({
  notification,
  onClose,
  onSent,
}) => {
  const [copied, setCopied] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);

  if (!notification) return null;

  const handleCopy = () => {
    navigator.clipboard.writeText(notification.rawMsg);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleCopyLink = () => {
    navigator.clipboard.writeText(notification.waLink);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
  };

  const handleSendWhatsApp = () => {
    window.open(notification.waLink, '_blank', 'noopener,noreferrer');
    onSent(notification.id);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
      <div className="bg-white rounded-2xl shadow-xl border border-slate-200 w-full max-w-lg overflow-hidden animate-in fade-in duration-200">
        {/* Header */}
        <div className="px-5 py-4 border-b border-slate-200 flex items-center justify-between bg-slate-50">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-emerald-100 text-emerald-700 flex items-center justify-center">
              <MessageSquare className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-800">
                معاينة إشعار الواتساب
              </h3>
              <p className="text-xs text-slate-500 font-mono" dir="ltr">
                {notification.phoneFull || notification.phone}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-600 p-1.5 rounded-lg hover:bg-slate-200/60 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-5 space-y-4">
          {/* Metadata badges */}
          <div className="grid grid-cols-2 gap-2 text-xs bg-slate-50 p-3 rounded-xl border border-slate-100">
            <div>
              <span className="text-slate-400 block text-[11px]">اسم العميل</span>
              <span className="font-semibold text-slate-800">
                {notification.clientName || 'غير محدد'}
              </span>
            </div>
            <div>
              <span className="text-slate-400 block text-[11px]">وقت الحركة</span>
              <span className="font-mono text-slate-700">
                {notification.movementTime || '—'}
              </span>
            </div>
            {notification.totalAccount && (
              <div className="col-span-2 pt-1 border-t border-slate-200/60">
                <span className="text-slate-400 block text-[11px]">إجمالي الحساب</span>
                <span className="font-mono font-semibold text-emerald-700">
                  {notification.totalAccount}
                </span>
              </div>
            )}
          </div>

          {/* WhatsApp Chat Simulation */}
          <div>
            <div className="text-[11px] font-semibold text-slate-500 mb-1.5">
              مظهر الرسالة داخل تطبيق واتساب:
            </div>
            <div className="bg-[#efeae2] p-4 rounded-xl border border-[#ded5c9] relative overflow-hidden shadow-inner">
              <div className="max-w-[92%] bg-[#dcf8c6] text-slate-800 p-3.5 rounded-lg rounded-tr-none shadow-xs text-xs leading-relaxed space-y-1 mr-auto font-sans">
                <div className="whitespace-pre-wrap select-text text-right" dir="rtl">
                  {notification.rawMsg}
                </div>
                <div className="flex items-center justify-end gap-1 text-[10px] text-slate-500 font-mono mt-1" dir="ltr">
                  <span>{notification.movementTime?.slice(-8) || 'Now'}</span>
                  <span>✓✓</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Actions */}
        <div className="px-5 py-4 bg-slate-50 border-t border-slate-200 flex flex-wrap items-center justify-between gap-2.5">
          <div className="flex items-center gap-2">
            <button
              onClick={handleCopy}
              type="button"
              className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-100 transition-colors"
            >
              {copied ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-600" />
                  <span className="text-emerald-700 font-semibold">تم النسخ</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5 text-slate-500" />
                  <span>نسخ النص</span>
                </>
              )}
            </button>

            <button
              onClick={handleCopyLink}
              type="button"
              className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-100 transition-colors"
              title="نسخ رابط wa.me المباشر"
            >
              {copiedLink ? (
                <Check className="w-3.5 h-3.5 text-emerald-600" />
              ) : (
                <ExternalLink className="w-3.5 h-3.5 text-slate-500" />
              )}
              <span>نسخ الرابط</span>
            </button>
          </div>

          <button
            onClick={handleSendWhatsApp}
            type="button"
            className="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-700 rounded-lg shadow-sm transition-all active:scale-[0.98]"
          >
            <Send className="w-3.5 h-3.5" />
            <span>فتح وإرسال عبر واتساب</span>
          </button>
        </div>
      </div>
    </div>
  );
};
