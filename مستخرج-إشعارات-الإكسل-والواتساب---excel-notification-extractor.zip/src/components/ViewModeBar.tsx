import React from 'react';
import { LayoutList, Table, CheckSquare, Square, MessageSquare, Smartphone } from 'lucide-react';

interface ViewModeBarProps {
  viewMode: 'feed' | 'table';
  onViewModeChange: (mode: 'feed' | 'table') => void;
  totalCount: number;
  selectedCount: number;
  onSelectAll: () => void;
  onDeselectAll: () => void;
  onStartBatchSend: (channel: 'whatsapp' | 'sms') => void;
}

export const ViewModeBar: React.FC<ViewModeBarProps> = ({
  viewMode,
  onViewModeChange,
  totalCount,
  selectedCount,
  onSelectAll,
  onDeselectAll,
  onStartBatchSend,
}) => {
  const isAllSelected = totalCount > 0 && selectedCount === totalCount;

  return (
    <div className="bg-white rounded-xl border border-slate-200 p-3.5 shadow-xs flex flex-wrap items-center justify-between gap-3">
      {/* View Switcher */}
      <div className="flex items-center gap-2">
        <span className="text-xs font-semibold text-slate-500">طريقة العرض:</span>
        <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-lg">
          <button
            onClick={() => onViewModeChange('feed')}
            type="button"
            className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold rounded-md transition-all ${
              viewMode === 'feed'
                ? 'bg-white text-emerald-800 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <LayoutList className="w-3.5 h-3.5 text-emerald-600" />
            <span>عرض بطاقات الرسائل (سحب للأسفل)</span>
          </button>

          <button
            onClick={() => onViewModeChange('table')}
            type="button"
            className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold rounded-md transition-all ${
              viewMode === 'table'
                ? 'bg-white text-emerald-800 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Table className="w-3.5 h-3.5 text-slate-500" />
            <span>عرض جدول البيانات</span>
          </button>
        </div>
      </div>

      {/* Select All & Batch Action */}
      <div className="flex items-center flex-wrap gap-2.5">
        {totalCount > 0 && (
          <button
            onClick={isAllSelected ? onDeselectAll : onSelectAll}
            type="button"
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 hover:text-slate-900 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-lg transition-colors"
          >
            {isAllSelected ? (
              <CheckSquare className="w-4 h-4 text-emerald-600" />
            ) : (
              <Square className="w-4 h-4 text-slate-400" />
            )}
            <span>
              {isAllSelected ? 'إلغاء تحديد الكل' : `تحديد الكل (${totalCount})`}
            </span>
          </button>
        )}

        {selectedCount > 0 && (
          <div className="flex items-center gap-1.5">
            <button
              onClick={() => onStartBatchSend('whatsapp')}
              type="button"
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-lg shadow-sm transition-all active:scale-[0.98]"
            >
              <MessageSquare className="w-3.5 h-3.5" />
              <span>إرسال واتساب ({selectedCount})</span>
            </button>

            <button
              onClick={() => onStartBatchSend('sms')}
              type="button"
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold text-white bg-sky-600 hover:bg-sky-700 rounded-lg shadow-sm transition-all active:scale-[0.98]"
            >
              <Smartphone className="w-3.5 h-3.5" />
              <span>إرسال SMS ({selectedCount})</span>
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
