import React from 'react';
import { FileSpreadsheet, Code2, RefreshCw, Send, HardDrive } from 'lucide-react';

interface HeaderProps {
  onLoadSample: () => void;
  onOpenPythonModal: () => void;
  onOpenQueueModal: () => void;
  onOpenDriveModal: () => void;
  isDriveConnected: boolean;
  boundFileName: string | null;
  totalFilteredCount: number;
  unsentCount: number;
}

export const Header: React.FC<HeaderProps> = ({
  onLoadSample,
  onOpenPythonModal,
  onOpenQueueModal,
  onOpenDriveModal,
  isDriveConnected,
  boundFileName,
  totalFilteredCount,
  unsentCount,
}) => {
  return (
    <header className="border-b border-slate-200 bg-white/95 backdrop-blur-sm sticky top-0 z-30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-4">
        {/* Zone 1: Single text element wordmark */}
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-emerald-600 flex items-center justify-center text-white shadow-sm shrink-0">
            <FileSpreadsheet className="w-5 h-5" />
          </div>
          <div>
            <h1 className="text-lg font-bold text-slate-900 tracking-tight leading-tight">
              مستخرج إشعارات الإكسل والواتساب
            </h1>
            <p className="text-xs text-slate-500 font-normal hidden sm:block">
              معالجة حسابات الإكسل · فك ترميز الإيموجي · إرسال واتساب و SMS · مزامنة Google Drive
            </p>
          </div>
        </div>

        {/* Zone 2: Navigation / Quick tool triggers */}
        <nav className="hidden md:flex items-center gap-2">
          {/* Google Drive Trigger */}
          <button
            onClick={onOpenDriveModal}
            type="button"
            className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap ${
              isDriveConnected
                ? 'bg-blue-50 text-blue-700 hover:bg-blue-100 border border-blue-200'
                : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
            }`}
          >
            <HardDrive className={`w-3.5 h-3.5 ${isDriveConnected ? 'text-blue-600' : 'text-slate-500'}`} />
            <span>{isDriveConnected ? 'Google Drive متزامن' : 'ربط Google Drive'}</span>
          </button>

          <button
            onClick={onLoadSample}
            type="button"
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 hover:text-emerald-700 hover:bg-emerald-50 rounded-lg transition-colors whitespace-nowrap"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>تجربة بيانات نموذجية</span>
          </button>

          <button
            onClick={onOpenPythonModal}
            type="button"
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition-colors whitespace-nowrap"
          >
            <Code2 className="w-3.5 h-3.5 text-slate-500" />
            <span>كود بايثون الأصلي</span>
          </button>
        </nav>

        {/* Zone 3: Primary Action */}
        <div className="flex items-center gap-2">
          {totalFilteredCount > 0 && (
            <button
              onClick={onOpenQueueModal}
              type="button"
              className="flex items-center gap-2 px-3.5 py-2 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-700 rounded-lg shadow-sm transition-all whitespace-nowrap active:scale-[0.98]"
            >
              <Send className="w-3.5 h-3.5" />
              <span>بدء إرسال المتتابع</span>
              {unsentCount > 0 && (
                <span className="bg-emerald-800 text-emerald-100 text-[11px] font-mono px-1.5 py-0.5 rounded-full">
                  {unsentCount}
                </span>
              )}
            </button>
          )}
        </div>
      </div>
    </header>
  );
};
