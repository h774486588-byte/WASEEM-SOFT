import React, { useState, useEffect } from 'react';
import { X, Send, ChevronRight, ChevronLeft, Check, SkipForward, ExternalLink } from 'lucide-react';
import { ProcessedNotification } from '../utils/excelParser';

interface SequentialSenderModalProps {
  notifications: ProcessedNotification[];
  isOpen: boolean;
  onClose: () => void;
  onMarkSent: (id: string) => void;
}

export const SequentialSenderModal: React.FC<SequentialSenderModalProps> = ({
  notifications,
  isOpen,
  onClose,
  onMarkSent,
}) => {
  const [currentIndex, setCurrentIndex] = useState(0);

  // Filter unsent or start from first unsent
  useEffect(() => {
    if (isOpen) {
      const firstUnsent = notifications.findIndex((n) => n.status !== 'sent');
      setCurrentIndex(firstUnsent !== -1 ? firstUnsent : 0);
    }
  }, [isOpen, notifications]);

  if (!isOpen || notifications.length === 0) return null;

  const currentItem = notifications[currentIndex];
  const isLast = currentIndex === notifications.length - 1;
  const isFirst = currentIndex === 0;
  const progressPercent = Math.round(((currentIndex + 1) / notifications.length) * 100);

  const handleSendAndNext = () => {
    if (!currentItem) return;
    window.open(currentItem.waLink, '_blank', 'noopener,noreferrer');
    onMarkSent(currentItem.id);
    if (!isLast) {
      setCurrentIndex((prev) => prev + 1);
    }
  };

  const handleNext = () => {
    if (!isLast) setCurrentIndex((prev) => prev + 1);
  };

  const handlePrev = () => {
    if (!isFirst) setCurrentIndex((prev) => prev - 1);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
      <div className="bg-white rounded-2xl shadow-xl border border-slate-200 w-full max-w-xl overflow-hidden animate-in fade-in duration-200">
        {/* Top Progress & Header */}
        <div className="px-5 py-4 border-b border-slate-200 bg-slate-50 flex items-center justify-between">
          <div>
            <span className="text-xs font-bold text-slate-800">
              معالج الإرسال المتتابع لواتساب
            </span>
            <div className="flex items-center gap-2 mt-0.5 text-xs text-slate-500">
              <span>الإشعار</span>
              <span className="font-mono font-semibold text-emerald-700">
                {currentIndex + 1}
              </span>
              <span>من أصل</span>
              <span className="font-mono font-semibold text-slate-800">
                {notifications.length}
              </span>
              <span className="font-mono text-slate-400">({progressPercent}%)</span>
            </div>
          </div>

          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-600 p-1.5 rounded-lg hover:bg-slate-200/60 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Progress Bar */}
        <div className="w-full bg-slate-100 h-1.5">
          <div
            className="bg-emerald-600 h-1.5 transition-all duration-300"
            style={{ width: `${progressPercent}%` }}
          />
        </div>

        {/* Current Notification Card */}
        {currentItem && (
          <div className="p-6 space-y-4">
            <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 flex flex-wrap items-center justify-between gap-3 text-xs">
              <div>
                <span className="text-slate-400 block text-[11px]">اسم العميل</span>
                <span className="text-sm font-bold text-slate-800">
                  {currentItem.clientName || 'عميل غير مسجل'}
                </span>
              </div>

              <div>
                <span className="text-slate-400 block text-[11px]">رقم الهاتف</span>
                <span className="font-mono font-semibold text-slate-800 text-sm tracking-wide" dir="ltr">
                  {currentItem.phoneFull || currentItem.phone}
                </span>
              </div>

              <div>
                <span className="text-slate-400 block text-[11px]">إجمالي الحساب</span>
                <span className="font-mono font-bold text-emerald-700">
                  {currentItem.totalAccount || '—'}
                </span>
              </div>
            </div>

            {/* Message preview */}
            <div>
              <span className="text-[11px] font-semibold text-slate-500 mb-1 block">
                محتوى الرسالة التي ستُرسل:
              </span>
              <div className="p-3.5 bg-emerald-50/50 border border-emerald-100 rounded-xl text-xs text-slate-700 whitespace-pre-wrap leading-relaxed max-h-48 overflow-y-auto">
                {currentItem.rawMsg}
              </div>
            </div>

            {/* Navigation row */}
            <div className="flex items-center justify-between text-xs text-slate-500 pt-2 border-t border-slate-100">
              <button
                onClick={handlePrev}
                disabled={isFirst}
                type="button"
                className="flex items-center gap-1 px-3 py-1.5 rounded-lg border border-slate-200 hover:bg-slate-50 disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
              >
                <ChevronRight className="w-4 h-4" />
                <span>السابق</span>
              </button>

              <span className="font-mono text-xs">
                {currentItem.status === 'sent' ? (
                  <span className="text-emerald-700 font-medium">✓ أُرسل مسبقاً</span>
                ) : (
                  <span className="text-amber-700 font-medium">● بانتظار الإرسال</span>
                )}
              </span>

              <button
                onClick={handleNext}
                disabled={isLast}
                type="button"
                className="flex items-center gap-1 px-3 py-1.5 rounded-lg border border-slate-200 hover:bg-slate-50 disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
              >
                <span>التالي</span>
                <ChevronLeft className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* Footer Actions */}
        <div className="px-6 py-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between gap-3">
          <button
            onClick={onClose}
            type="button"
            className="px-4 py-2 text-xs font-medium text-slate-600 hover:text-slate-800"
          >
            إنهاء الجلسة
          </button>

          <button
            onClick={handleSendAndNext}
            type="button"
            className="flex items-center gap-2 px-5 py-2.5 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-xl shadow-md transition-all active:scale-[0.98]"
          >
            <Send className="w-4 h-4" />
            <span>إرسال عبر واتساب والانتقال للتالي</span>
            <ExternalLink className="w-3.5 h-3.5 opacity-75" />
          </button>
        </div>
      </div>
    </div>
  );
};
