import React from 'react';
import { Calendar, Search, Filter, X, ShieldCheck, CopySlash, Layers } from 'lucide-react';

interface DateCount {
  date: string;
  count: number;
}

interface DateFilterBarProps {
  availableDates: DateCount[];
  selectedDate: string;
  onSelectDate: (date: string) => void;
  searchQuery: string;
  onSearchChange: (query: string) => void;
  statusFilter: 'all' | 'unsent' | 'sent_wa' | 'sent_sms';
  onStatusFilterChange: (status: 'all' | 'unsent' | 'sent_wa' | 'sent_sms') => void;
  dedupMode: 'phone_and_msg' | 'phone_only' | 'none';
  onDedupModeChange: (mode: 'phone_and_msg' | 'phone_only' | 'none') => void;
  duplicateCount: number;
}

export const DateFilterBar: React.FC<DateFilterBarProps> = ({
  availableDates,
  selectedDate,
  onSelectDate,
  searchQuery,
  onSearchChange,
  statusFilter,
  onStatusFilterChange,
  dedupMode,
  onDedupModeChange,
  duplicateCount,
}) => {
  return (
    <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-xs space-y-3.5">
      {/* Top Row: Strict Date Selector + Deduplication Toggle */}
      <div className="flex flex-col xl:flex-row xl:items-center justify-between gap-3">
        {/* Date Selector Tabs */}
        <div className="flex items-center gap-2 overflow-x-auto pb-1 xl:pb-0 scrollbar-thin">
          <span className="text-xs font-bold text-slate-800 whitespace-nowrap flex items-center gap-1.5 shrink-0">
            <Calendar className="w-4 h-4 text-emerald-600" />
            تاريخ الكشف المطلوب حصراً:
          </span>

          <div className="flex items-center gap-1.5 p-1 bg-slate-100 rounded-lg shrink-0">
            {availableDates.map(({ date, count }) => (
              <button
                key={date}
                onClick={() => onSelectDate(date)}
                type="button"
                className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-md transition-all whitespace-nowrap ${
                  selectedDate === date
                    ? 'bg-emerald-600 text-white shadow-xs font-bold'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
                }`}
              >
                <span className="font-mono">{date}</span>
                <span
                  className={`text-[10px] font-mono px-1.5 py-0.2 rounded-full ${
                    selectedDate === date ? 'bg-emerald-800 text-white' : 'bg-slate-200 text-slate-700'
                  }`}
                >
                  {count}
                </span>
              </button>
            ))}

            <button
              onClick={() => onSelectDate('')}
              type="button"
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
                selectedDate === ''
                  ? 'bg-slate-900 text-white shadow-xs font-semibold'
                  : 'text-slate-500 hover:text-slate-800'
              }`}
              title="عرض كافة التواريخ الموجودة في الكشف"
            >
              عرض الكل
            </button>
          </div>

          {/* Manual Date Input */}
          <div className="flex items-center gap-1 bg-slate-50 border border-slate-200 px-2 py-1 rounded-lg text-xs shrink-0">
            <input
              type="date"
              value={selectedDate}
              onChange={(e) => onSelectDate(e.target.value)}
              className="text-xs font-mono text-slate-800 bg-transparent focus:outline-none"
              title="تحديد تاريخ يدوي بصيغة YYYY-MM-DD"
            />
            {selectedDate && (
              <button
                onClick={() => onSelectDate('')}
                className="text-slate-400 hover:text-slate-600 p-0.5"
                title="إلغاء فلتر التاريخ"
              >
                <X className="w-3 h-3" />
              </button>
            )}
          </div>
        </div>

        {/* Deduplication Control */}
        <div className="flex items-center gap-2 bg-slate-50 border border-slate-200/90 p-1.5 rounded-lg text-xs shrink-0">
          <div className="flex items-center gap-1.5 text-slate-700 font-semibold px-1">
            <ShieldCheck className="w-4 h-4 text-emerald-600" />
            <span>منع التكرار:</span>
          </div>

          <select
            value={dedupMode}
            onChange={(e) => onDedupModeChange(e.target.value as any)}
            className="bg-white border border-slate-300 rounded-md px-2 py-1 text-xs font-medium text-slate-800 focus:outline-emerald-500"
          >
            <option value="phone_and_msg">استبعاد نفس الرسالة لنفس الرقم (موصى به)</option>
            <option value="phone_only">رسالة واحدة كحد أقصى لكل رقم هاتف</option>
            <option value="none">السماح بالتكرار (إظهار كافة أسطر الملف)</option>
          </select>

          {duplicateCount > 0 && dedupMode !== 'none' && (
            <span className="text-[11px] font-mono font-bold text-amber-700 bg-amber-100 px-2 py-0.5 rounded-md shrink-0">
              تم استبعاد {duplicateCount} مكرر
            </span>
          )}
        </div>
      </div>

      {/* Bottom Row: Search & Status Filters */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 pt-1 border-t border-slate-100">
        {/* Active strict date notification message */}
        <div className="text-xs text-slate-600 flex items-center gap-1.5">
          {selectedDate ? (
            <>
              <span className="w-2 h-2 rounded-full bg-emerald-500 shrink-0" />
              <span>يتم عرض الرسائل المسجلة بتاريخ</span>
              <span className="font-mono font-bold text-emerald-700 bg-emerald-50 px-1.5 py-0.5 rounded">
                {selectedDate}
              </span>
              <span>فقط في هذا الكشف.</span>
            </>
          ) : (
            <span className="text-slate-400">
              يتم عرض رسائل كافة التواريخ. انقر على تاريخ محدد أعلاه لحصره فقط.
            </span>
          )}
        </div>

        {/* Live Search & Status Tabs */}
        <div className="flex items-center gap-2.5">
          {/* Live Search */}
          <div className="relative flex-1 sm:w-60">
            <Search className="w-3.5 h-3.5 absolute right-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => onSearchChange(e.target.value)}
              placeholder="بحث بالاسم أو الهاتف..."
              className="w-full text-xs pr-8 pl-3 py-1.5 bg-slate-50 hover:bg-white focus:bg-white border border-slate-200 rounded-lg text-slate-800 focus:outline-emerald-500 transition-colors"
            />
            {searchQuery && (
              <button
                onClick={() => onSearchChange('')}
                className="absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
              >
                <X className="w-3 h-3" />
              </button>
            )}
          </div>

          {/* Status Segmented Filter */}
          <div className="flex items-center gap-1 p-0.5 bg-slate-100 rounded-lg shrink-0 text-xs">
            <button
              onClick={() => onStatusFilterChange('all')}
              type="button"
              className={`px-2 py-1 text-xs font-medium rounded-md transition-colors ${
                statusFilter === 'all'
                  ? 'bg-white text-slate-900 shadow-xs font-semibold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              الكل
            </button>
            <button
              onClick={() => onStatusFilterChange('unsent')}
              type="button"
              className={`px-2 py-1 text-xs font-medium rounded-md transition-colors ${
                statusFilter === 'unsent'
                  ? 'bg-white text-amber-700 shadow-xs font-semibold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              لم يُرسل
            </button>
            <button
              onClick={() => onStatusFilterChange('sent_wa')}
              type="button"
              className={`px-2 py-1 text-xs font-medium rounded-md transition-colors ${
                statusFilter === 'sent_wa'
                  ? 'bg-emerald-600 text-white shadow-xs font-semibold'
                  : 'text-slate-600 hover:text-emerald-700'
              }`}
            >
              أُرسل واتساب
            </button>
            <button
              onClick={() => onStatusFilterChange('sent_sms')}
              type="button"
              className={`px-2 py-1 text-xs font-medium rounded-md transition-colors ${
                statusFilter === 'sent_sms'
                  ? 'bg-sky-600 text-white shadow-xs font-semibold'
                  : 'text-slate-600 hover:text-sky-700'
              }`}
            >
              أُرسل SMS
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
