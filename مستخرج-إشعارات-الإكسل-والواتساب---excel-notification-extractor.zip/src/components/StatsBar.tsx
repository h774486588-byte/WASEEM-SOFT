import React from 'react';
import { ShieldCheck, Calendar, FileText, MessageSquare, Smartphone, Clock } from 'lucide-react';

interface StatsBarProps {
  totalInFile: number;
  totalForDate: number;
  whatsappSentCount: number;
  smsSentCount: number;
  unsentCount: number;
  duplicateCount: number;
  selectedDate: string;
  fileName: string;
  isDeduplicationActive: boolean;
}

export const StatsBar: React.FC<StatsBarProps> = ({
  totalInFile,
  totalForDate,
  whatsappSentCount,
  smsSentCount,
  unsentCount,
  duplicateCount,
  selectedDate,
  fileName,
  isDeduplicationActive,
}) => {
  return (
    <div className="bg-white border-b border-slate-200 px-4 sm:px-6 lg:px-8 py-3">
      <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-y-2.5 gap-x-6 text-xs text-slate-600">
        {/* Left side: Active File & Strict Date Target */}
        <div className="flex items-center flex-wrap gap-2 text-slate-700">
          <div className="flex items-center gap-1.5 font-semibold text-slate-900">
            <FileText className="w-3.5 h-3.5 text-emerald-600" />
            <span>الكشف:</span>
            <span className="font-mono text-emerald-800">{fileName || 'لم يتم اختيار ملف'}</span>
          </div>

          <span aria-hidden="true" className="text-slate-300">·</span>

          <div className="flex items-center gap-1.5">
            <Calendar className="w-3.5 h-3.5 text-slate-400" />
            <span className="text-slate-500">تاريخ الكشف فقط:</span>
            <span className="font-mono font-bold text-slate-900 bg-emerald-50 border border-emerald-200 text-emerald-800 px-2 py-0.5 rounded-md">
              {selectedDate || 'كافة التواريخ'}
            </span>
          </div>

          {/* Deduplication Status Badge */}
          {isDeduplicationActive && (
            <>
              <span aria-hidden="true" className="text-slate-300">·</span>
              <div className="flex items-center gap-1 text-[11px] font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                <span>منع التكرار</span>
                {duplicateCount > 0 && (
                  <span className="font-mono bg-emerald-700 text-white px-1.5 py-0.2 rounded-full text-[10px]">
                    استبعاد {duplicateCount}
                  </span>
                )}
              </div>
            </>
          )}
        </div>

        {/* Right side: Key metric figures with WhatsApp and SMS stats */}
        <div className="flex items-center flex-wrap gap-3 text-xs">
          <div className="flex items-center gap-1">
            <span className="text-slate-500">رسائل اليوم:</span>
            <span className="font-mono font-bold text-slate-800 tabular-nums">
              {totalForDate}
            </span>
          </div>

          <span aria-hidden="true" className="text-slate-300">·</span>

          {/* WhatsApp Sent Count */}
          <div className="flex items-center gap-1.5 bg-emerald-50 text-emerald-800 px-2 py-0.5 rounded-md border border-emerald-200 font-semibold">
            <MessageSquare className="w-3 h-3 text-emerald-600" />
            <span>واتساب:</span>
            <span className="font-mono font-bold tabular-nums">
              {whatsappSentCount}
            </span>
          </div>

          <span aria-hidden="true" className="text-slate-300">·</span>

          {/* SMS Sent Count */}
          <div className="flex items-center gap-1.5 bg-sky-50 text-sky-800 px-2 py-0.5 rounded-md border border-sky-200 font-semibold">
            <Smartphone className="w-3 h-3 text-sky-600" />
            <span>SMS:</span>
            <span className="font-mono font-bold tabular-nums">
              {smsSentCount}
            </span>
          </div>

          <span aria-hidden="true" className="text-slate-300">·</span>

          {/* Remaining Unsent */}
          <div className="flex items-center gap-1 text-slate-500">
            <span>بانتظار الإرسال:</span>
            <span className="font-mono font-semibold text-amber-600 tabular-nums">
              {unsentCount}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};
