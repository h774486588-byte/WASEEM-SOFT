import React from 'react';
import { Send, CheckSquare, Square, X, Check, Phone, MessageSquare, Smartphone } from 'lucide-react';

interface StickyBottomBarProps {
  selectedCount: number;
  totalCount: number;
  onStartBatchSend: (channel: 'whatsapp' | 'sms') => void;
  onSelectAll: () => void;
  onDeselectAll: () => void;
  onMarkSelectedWhatsAppSent: () => void;
  onMarkSelectedSmsSent: () => void;
  onCopySelectedPhones: () => void;
  copiedPhones: boolean;
}

export const StickyBottomBar: React.FC<StickyBottomBarProps> = ({
  selectedCount,
  totalCount,
  onStartBatchSend,
  onSelectAll,
  onDeselectAll,
  onMarkSelectedWhatsAppSent,
  onMarkSelectedSmsSent,
  onCopySelectedPhones,
  copiedPhones,
}) => {
  if (selectedCount === 0) return null;

  return (
    <div className="fixed bottom-4 inset-x-4 max-w-4xl mx-auto z-40 animate-in slide-in-from-bottom-4 duration-200">
      <div className="bg-slate-900 text-white rounded-2xl p-3.5 shadow-2xl border border-slate-800 flex flex-wrap items-center justify-between gap-3">
        {/* Selection Status */}
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-emerald-600 flex items-center justify-center font-mono font-bold text-xs text-white">
            {selectedCount}
          </div>
          <div>
            <div className="text-xs font-bold text-white flex items-center gap-1.5">
              <span>تم تحديد {selectedCount} رسالة</span>
              <span className="text-slate-400 font-normal">من أصل {totalCount}</span>
            </div>
            <p className="text-[11px] text-slate-400">
              جاهزة للإرسال المتتابع عبر واتساب أو رسائل SMS
            </p>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center flex-wrap gap-2">
          {/* Copy phones */}
          <button
            onClick={onCopySelectedPhones}
            type="button"
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-200 bg-slate-800 hover:bg-slate-700 rounded-lg transition-colors"
          >
            {copiedPhones ? (
              <>
                <Check className="w-3.5 h-3.5 text-emerald-400" />
                <span className="text-emerald-400">تم النسخ</span>
              </>
            ) : (
              <>
                <Phone className="w-3.5 h-3.5 text-slate-400" />
                <span>نسخ الأرقام</span>
              </>
            )}
          </button>

          {/* Deselect All */}
          <button
            onClick={onDeselectAll}
            type="button"
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
            title="إلغاء التحديد"
          >
            <X className="w-4 h-4" />
          </button>

          {/* Start Sequential SMS Send */}
          <button
            onClick={() => onStartBatchSend('sms')}
            type="button"
            className="flex items-center gap-1.5 px-4 py-2 text-xs font-bold text-white bg-sky-600 hover:bg-sky-500 rounded-xl shadow-md transition-all active:scale-[0.98]"
          >
            <Smartphone className="w-3.5 h-3.5" />
            <span>إرسال SMS ({selectedCount})</span>
          </button>

          {/* Start Sequential WhatsApp Send */}
          <button
            onClick={() => onStartBatchSend('whatsapp')}
            type="button"
            className="flex items-center gap-1.5 px-4 py-2 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-500 rounded-xl shadow-md transition-all active:scale-[0.98]"
          >
            <MessageSquare className="w-3.5 h-3.5" />
            <span>إرسال واتساب ({selectedCount})</span>
          </button>
        </div>
      </div>
    </div>
  );
};
