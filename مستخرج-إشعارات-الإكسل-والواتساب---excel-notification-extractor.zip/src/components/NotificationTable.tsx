import React, { useState } from 'react';
import {
  ExternalLink,
  Copy,
  Check,
  Eye,
  FileSpreadsheet,
  Download,
  Phone,
  MessageSquare,
  Smartphone,
  AlertCircle,
  Square,
  CheckSquare,
  Send
} from 'lucide-react';
import { ProcessedNotification, exportToExcel, exportToCsv } from '../utils/excelParser';
import { ChannelStatusBadge } from './ChannelStatusBadge';

interface NotificationTableProps {
  notifications: ProcessedNotification[];
  selectedDate: string;
  selectedIds: Set<string>;
  onToggleSelect: (id: string) => void;
  onSelectAll: () => void;
  onDeselectAll: () => void;
  onToggleWhatsAppStatus: (id: string) => void;
  onToggleSmsStatus: (id: string) => void;
  onPreviewMessage: (notification: ProcessedNotification) => void;
  onMarkAllWhatsAppSent: () => void;
  onMarkAllSmsSent: () => void;
  onResetStatus: () => void;
  onStartBatchSend: (channel: 'whatsapp' | 'sms') => void;
  onSingleSendWhatsApp: (item: ProcessedNotification) => void;
  onSingleSendSms: (item: ProcessedNotification) => void;
}

export const NotificationTable: React.FC<NotificationTableProps> = ({
  notifications,
  selectedDate,
  selectedIds,
  onToggleSelect,
  onSelectAll,
  onDeselectAll,
  onToggleWhatsAppStatus,
  onToggleSmsStatus,
  onPreviewMessage,
  onMarkAllWhatsAppSent,
  onMarkAllSmsSent,
  onResetStatus,
  onStartBatchSend,
  onSingleSendWhatsApp,
  onSingleSendSms,
}) => {
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const [copiedNumbers, setCopiedNumbers] = useState(false);

  const isAllSelected =
    notifications.length > 0 && notifications.every((n) => selectedIds.has(n.id));
  const selectedCount = notifications.filter((n) => selectedIds.has(n.id)).length;

  const handleCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 1800);
  };

  const handleCopyAllPhones = () => {
    const phones = notifications.map((n) => n.phoneFull || n.phone).filter(Boolean);
    navigator.clipboard.writeText(phones.join('\n'));
    setCopiedNumbers(true);
    setTimeout(() => setCopiedNumbers(false), 2000);
  };

  if (notifications.length === 0) {
    return (
      <div className="bg-white rounded-xl border border-slate-200 p-12 text-center shadow-xs">
        <div className="w-12 h-12 rounded-full bg-slate-100 text-slate-400 flex items-center justify-center mx-auto mb-3">
          <AlertCircle className="w-6 h-6" />
        </div>
        <h3 className="text-sm font-semibold text-slate-800">
          لا توجد إشعارات مسجلة لهذا التاريخ أو معايير البحث
        </h3>
        <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
          يرجى اختيار تاريخ آخر من شريط التواريخ بالأعلى أو إعادة ضبط معايير البحث والفلترة.
        </p>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
      {/* Table Action Bar */}
      <div className="p-4 border-b border-slate-200 flex flex-wrap items-center justify-between gap-3 bg-slate-50/50">
        <div className="flex items-center gap-2">
          {/* Select all toggle button */}
          <button
            onClick={isAllSelected ? onDeselectAll : onSelectAll}
            type="button"
            className="flex items-center gap-1.5 text-xs font-bold text-slate-700 hover:text-emerald-700 bg-white border border-slate-200 px-2.5 py-1 rounded-md transition-colors"
          >
            {isAllSelected ? (
              <CheckSquare className="w-4 h-4 text-emerald-600" />
            ) : (
              <Square className="w-4 h-4 text-slate-400" />
            )}
            <span>{isAllSelected ? 'إلغاء التحديد' : 'تحديد الكل'}</span>
          </button>

          <span className="text-xs font-semibold text-slate-800">
            نتائج الإشعارات ({notifications.length})
          </span>

          {selectedCount > 0 && (
            <span className="text-xs font-semibold text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded-full">
              محدد: {selectedCount}
            </span>
          )}

          <span aria-hidden="true" className="text-slate-300">·</span>

          <button
            onClick={handleCopyAllPhones}
            type="button"
            className="flex items-center gap-1.5 px-2.5 py-1 text-xs font-medium text-slate-600 hover:text-slate-900 bg-white border border-slate-200 rounded-md hover:bg-slate-100 transition-colors"
          >
            {copiedNumbers ? (
              <>
                <Check className="w-3.5 h-3.5 text-emerald-600" />
                <span className="text-emerald-700">تم نسخ {notifications.length} رقم!</span>
              </>
            ) : (
              <>
                <Phone className="w-3.5 h-3.5 text-slate-400" />
                <span>نسخ كافة الأرقام</span>
              </>
            )}
          </button>
        </div>

        {/* Export and Batch Buttons */}
        <div className="flex items-center flex-wrap gap-2">
          {/* Batch send options */}
          <button
            onClick={() => onStartBatchSend('whatsapp')}
            type="button"
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-lg shadow-xs transition-all active:scale-[0.98]"
          >
            <MessageSquare className="w-3.5 h-3.5" />
            <span>متتابع واتساب ({selectedCount || notifications.length})</span>
          </button>

          <button
            onClick={() => onStartBatchSend('sms')}
            type="button"
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold text-white bg-sky-600 hover:bg-sky-700 rounded-lg shadow-xs transition-all active:scale-[0.98]"
          >
            <Smartphone className="w-3.5 h-3.5" />
            <span>متتابع SMS ({selectedCount || notifications.length})</span>
          </button>

          <div className="h-4 w-px bg-slate-200 mx-1" />

          <button
            onClick={() => exportToExcel(notifications, selectedDate)}
            type="button"
            className="flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-medium text-slate-700 bg-white hover:bg-slate-50 border border-slate-200 rounded-lg transition-colors whitespace-nowrap"
            title="تصدير إلى ملف إكسل بتنسيق مطابق لمخرجات بايثون"
          >
            <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-700" />
            <span>Excel</span>
          </button>

          <button
            onClick={() => exportToCsv(notifications, selectedDate)}
            type="button"
            className="flex items-center gap-1.5 px-2 py-1.5 text-xs font-medium text-slate-700 bg-white hover:bg-slate-50 border border-slate-200 rounded-lg transition-colors whitespace-nowrap"
            title="تصدير ملف CSV"
          >
            <Download className="w-3.5 h-3.5 text-slate-500" />
            <span>CSV</span>
          </button>
        </div>
      </div>

      {/* High-Density Data Grid */}
      <div className="overflow-x-auto">
        <table className="w-full text-right text-xs">
          <thead className="bg-slate-100/75 border-b border-slate-200 text-slate-700 font-semibold select-none">
            <tr>
              <th className="py-3 px-3 w-10 text-center">
                <button
                  onClick={isAllSelected ? onDeselectAll : onSelectAll}
                  type="button"
                  className="text-slate-500 hover:text-emerald-600"
                >
                  {isAllSelected ? (
                    <CheckSquare className="w-4 h-4 text-emerald-600" />
                  ) : (
                    <Square className="w-4 h-4" />
                  )}
                </button>
              </th>
              <th className="py-3 px-3 w-10 text-center">#</th>
              <th className="py-3 px-4 min-w-[130px]">رقم الهاتف</th>
              <th className="py-3 px-4 min-w-[150px]">اسم العميل</th>
              <th className="py-3 px-4 min-w-[110px]">وقت الحركة</th>
              <th className="py-3 px-4 min-w-[120px]">إجمالي الحساب</th>
              <th className="py-3 px-4 min-w-[260px]">نص الإشعار</th>
              <th className="py-3 px-3 min-w-[160px] text-center">حالة الإرسال (واتساب / SMS)</th>
              <th className="py-3 px-4 min-w-[180px] text-center">إجراءات الإرسال</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {notifications.map((item, idx) => {
              const isExpanded = expandedId === item.id;
              const isSelected = selectedIds.has(item.id);

              return (
                <tr
                  key={item.id}
                  className={`hover:bg-slate-50/80 transition-colors group ${
                    isSelected ? 'bg-emerald-50/40' : item.whatsappSent || item.smsSent ? 'bg-slate-50/40' : ''
                  }`}
                >
                  {/* Select Checkbox */}
                  <td className="py-3 px-3 text-center">
                    <button
                      onClick={() => onToggleSelect(item.id)}
                      type="button"
                      className="text-slate-400 hover:text-emerald-600"
                    >
                      {isSelected ? (
                        <CheckSquare className="w-4 h-4 text-emerald-600" />
                      ) : (
                        <Square className="w-4 h-4 text-slate-300 hover:text-slate-500" />
                      )}
                    </button>
                  </td>

                  {/* Index */}
                  <td className="py-3 px-3 text-center font-mono text-slate-400 tabular-nums">
                    {idx + 1}
                  </td>

                  {/* Phone */}
                  <td className="py-3 px-4 font-mono font-medium text-slate-800 tabular-nums">
                    <div className="flex items-center gap-1.5">
                      <span dir="ltr" className="tracking-wide">
                        {item.phoneFull || item.phone}
                      </span>
                      <button
                        onClick={() => handleCopy(item.phoneFull || item.phone, `p-${item.id}`)}
                        className="opacity-0 group-hover:opacity-100 text-slate-400 hover:text-slate-600 transition-opacity p-0.5"
                        title="نسخ الرقم"
                      >
                        {copiedId === `p-${item.id}` ? (
                          <Check className="w-3 h-3 text-emerald-600" />
                        ) : (
                          <Copy className="w-3 h-3" />
                        )}
                      </button>
                    </div>
                  </td>

                  {/* Client Name */}
                  <td className="py-3 px-4 font-semibold text-slate-800">
                    {item.clientName ? (
                      <span className="truncate block max-w-[180px]" title={item.clientName}>
                        {item.clientName}
                      </span>
                    ) : (
                      <span className="text-slate-400 italic font-normal">غير محدد</span>
                    )}
                  </td>

                  {/* Movement Time */}
                  <td className="py-3 px-4 font-mono text-slate-600 tabular-nums whitespace-nowrap text-[11px]">
                    {item.movementTime || '—'}
                  </td>

                  {/* Total Balance */}
                  <td className="py-3 px-4 font-mono font-semibold text-emerald-700 tabular-nums whitespace-nowrap">
                    {item.totalAccount || '—'}
                  </td>

                  {/* Notification text preview */}
                  <td className="py-3 px-4 text-slate-600">
                    <div className="relative">
                      <p
                        className={`text-[11px] leading-relaxed transition-all ${
                          isExpanded ? 'whitespace-pre-wrap' : 'line-clamp-2 max-w-md'
                        }`}
                      >
                        {item.rawMsg}
                      </p>
                      {item.rawMsg.length > 70 && (
                        <button
                          onClick={() => setExpandedId(isExpanded ? null : item.id)}
                          className="text-[10px] text-emerald-600 hover:text-emerald-700 font-medium mt-0.5 inline-block"
                        >
                          {isExpanded ? 'إخفاء' : 'عرض المزيد...'}
                        </button>
                      )}
                    </div>
                  </td>

                  {/* Dual Channel Status Badges */}
                  <td className="py-3 px-3 text-center">
                    <div className="flex justify-center">
                      <ChannelStatusBadge
                        whatsappSent={item.whatsappSent}
                        smsSent={item.smsSent}
                        onToggleWhatsApp={() => onToggleWhatsAppStatus(item.id)}
                        onToggleSms={() => onToggleSmsStatus(item.id)}
                        size="sm"
                      />
                    </div>
                  </td>

                  {/* Actions: Send WhatsApp, Send SMS, Copy, Preview */}
                  <td className="py-3 px-4 text-center">
                    <div className="flex items-center justify-center gap-1.5">
                      {/* Individual SMS button */}
                      <button
                        onClick={() => onSingleSendSms(item)}
                        type="button"
                        className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-semibold text-white bg-sky-600 hover:bg-sky-700 rounded-md shadow-2xs transition-colors whitespace-nowrap"
                        title="إرسال رسالة SMS قصيرة"
                      >
                        <Smartphone className="w-3 h-3" />
                        <span>SMS</span>
                        {item.smsSent && <Check className="w-3 h-3 text-sky-200" />}
                      </button>

                      {/* Individual WhatsApp button */}
                      <button
                        onClick={() => onSingleSendWhatsApp(item)}
                        type="button"
                        className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-700 rounded-md shadow-2xs transition-colors whitespace-nowrap"
                        title="إرسال عبر واتساب"
                      >
                        <MessageSquare className="w-3 h-3" />
                        <span>واتساب</span>
                        {item.whatsappSent && <Check className="w-3 h-3 text-emerald-200" />}
                      </button>

                      {/* Preview Button */}
                      <button
                        onClick={() => onPreviewMessage(item)}
                        type="button"
                        className="p-1 text-slate-500 hover:text-slate-800 hover:bg-slate-100 rounded-md transition-colors"
                        title="معاينة الرسالة"
                      >
                        <Eye className="w-3.5 h-3.5" />
                      </button>

                      {/* Copy Message */}
                      <button
                        onClick={() => handleCopy(item.rawMsg, `m-${item.id}`)}
                        type="button"
                        className="p-1 text-slate-500 hover:text-slate-800 hover:bg-slate-100 rounded-md transition-colors"
                        title="نسخ نص الإشعار"
                      >
                        {copiedId === `m-${item.id}` ? (
                          <Check className="w-3.5 h-3.5 text-emerald-600" />
                        ) : (
                          <Copy className="w-3.5 h-3.5" />
                        )}
                      </button>
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {/* Table Footer */}
      <div className="p-3 bg-slate-50 border-t border-slate-200 text-xs text-slate-500 flex flex-wrap items-center justify-between gap-3">
        <span>
          عرض <span className="font-mono font-semibold text-slate-700">{notifications.length}</span> إشعار مستخرج
        </span>

        <div className="flex items-center gap-3">
          <button
            onClick={onMarkAllWhatsAppSent}
            type="button"
            className="text-emerald-700 hover:underline font-medium text-xs"
          >
            تحديد الكل كمرسل واتساب
          </button>
          <span className="text-slate-300">·</span>
          <button
            onClick={onMarkAllSmsSent}
            type="button"
            className="text-sky-700 hover:underline font-medium text-xs"
          >
            تحديد الكل كمرسل SMS
          </button>
          <span className="text-slate-300">·</span>
          <button
            onClick={onResetStatus}
            type="button"
            className="text-slate-500 hover:text-red-600 text-xs transition-colors"
          >
            إعادة ضبط الحالات
          </button>
        </div>
      </div>
    </div>
  );
};
