import React, { useState, useEffect, useRef } from 'react';
import {
  X,
  Send,
  Play,
  Pause,
  SkipForward,
  RotateCcw,
  CheckCircle2,
  Clock,
  ExternalLink,
  MessageSquare,
  Smartphone,
  AlertCircle
} from 'lucide-react';
import { ProcessedNotification } from '../utils/excelParser';

interface AutoDispatcherModalProps {
  notifications: ProcessedNotification[];
  isOpen: boolean;
  onClose: () => void;
  initialChannel?: 'whatsapp' | 'sms';
  onMarkSent: (id: string, channel: 'whatsapp' | 'sms') => void;
}

export const AutoDispatcherModal: React.FC<AutoDispatcherModalProps> = ({
  notifications,
  isOpen,
  onClose,
  initialChannel = 'whatsapp',
  onMarkSent,
}) => {
  const [channel, setChannel] = useState<'whatsapp' | 'sms'>(initialChannel);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isAutoPlaying, setIsAutoPlaying] = useState(false);
  const [intervalSeconds, setIntervalSeconds] = useState(4);
  const [countdown, setCountdown] = useState(4);
  const timerRef = useRef<any>(null);

  // Sync initial channel when opened
  useEffect(() => {
    if (isOpen) {
      setChannel(initialChannel);
      // Find first unsent for this channel
      const firstUnsent = notifications.findIndex((n) =>
        initialChannel === 'whatsapp' ? !n.whatsappSent : !n.smsSent
      );
      setCurrentIndex(firstUnsent !== -1 ? firstUnsent : 0);
      setIsAutoPlaying(false);
      setCountdown(intervalSeconds);
    } else {
      if (timerRef.current) clearInterval(timerRef.current);
      setIsAutoPlaying(false);
    }
  }, [isOpen, initialChannel]);

  // Clean timer on unmount
  useEffect(() => {
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, []);

  const currentItem = notifications[currentIndex];
  const totalCount = notifications.length;
  const isFinished = currentIndex >= totalCount;

  // Auto-play timer effect
  useEffect(() => {
    if (!isAutoPlaying || isFinished || !currentItem) {
      if (timerRef.current) clearInterval(timerRef.current);
      return;
    }

    setCountdown(intervalSeconds);

    timerRef.current = setInterval(() => {
      setCountdown((prev) => {
        if (prev <= 1) {
          triggerSend(currentIndex);
          return intervalSeconds;
        }
        return prev - 1;
      });
    }, 1000);

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [isAutoPlaying, currentIndex, isFinished, intervalSeconds, channel]);

  const triggerSend = (index: number) => {
    const item = notifications[index];
    if (!item) return;

    if (channel === 'whatsapp') {
      window.open(item.waLink, '_blank', 'noopener,noreferrer');
      onMarkSent(item.id, 'whatsapp');
    } else {
      // SMS: Opens SMS app or web protocol
      window.open(item.smsLink, '_blank', 'noopener,noreferrer');
      onMarkSent(item.id, 'sms');
    }

    // Advance to next
    if (index + 1 < totalCount) {
      setCurrentIndex(index + 1);
    } else {
      setIsAutoPlaying(false);
      setCurrentIndex(totalCount); // Done!
    }
  };

  const handleManualSendAndNext = () => {
    triggerSend(currentIndex);
  };

  const handleSkip = () => {
    if (currentIndex + 1 < totalCount) {
      setCurrentIndex((prev) => prev + 1);
      setCountdown(intervalSeconds);
    }
  };

  const toggleAutoPlay = () => {
    if (!isAutoPlaying) {
      setCountdown(intervalSeconds);
      setIsAutoPlaying(true);
    } else {
      setIsAutoPlaying(false);
      if (timerRef.current) clearInterval(timerRef.current);
    }
  };

  if (!isOpen) return null;

  const isCurrentSent = currentItem
    ? channel === 'whatsapp'
      ? currentItem.whatsappSent
      : currentItem.smsSent
    : false;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-xl overflow-hidden animate-in fade-in duration-200">
        {/* Header */}
        <div className="px-5 py-4 border-b border-slate-200 bg-slate-50 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div
              className={`w-9 h-9 rounded-xl flex items-center justify-center text-white shadow-xs ${
                channel === 'whatsapp' ? 'bg-emerald-600' : 'bg-sky-600'
              }`}
            >
              {channel === 'whatsapp' ? (
                <MessageSquare className="w-4 h-4" />
              ) : (
                <Smartphone className="w-4 h-4" />
              )}
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-800">
                مرسل الإشعارات المتتابع ({channel === 'whatsapp' ? 'عبر واتساب' : 'عبر رسائل SMS'})
              </h3>
              <p className="text-xs text-slate-500">
                إرسال متتابع للرسائل المحددة ({totalCount} رسالة) واحدة تلو الأخرى
              </p>
            </div>
          </div>

          <button
            onClick={() => {
              setIsAutoPlaying(false);
              onClose();
            }}
            className="text-slate-400 hover:text-slate-600 p-1.5 rounded-lg hover:bg-slate-200/60 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Channel Switcher Tab inside modal */}
        <div className="bg-slate-100/80 px-5 py-2.5 border-b border-slate-200 flex items-center justify-between gap-3">
          <span className="text-xs font-semibold text-slate-600">قناة الإرسال المستهدفة:</span>
          <div className="flex items-center gap-1.5 bg-white p-1 rounded-lg border border-slate-200 shadow-2xs">
            <button
              onClick={() => {
                setChannel('whatsapp');
                setIsAutoPlaying(false);
              }}
              type="button"
              className={`flex items-center gap-1.5 px-3 py-1 rounded-md text-xs font-bold transition-all ${
                channel === 'whatsapp'
                  ? 'bg-emerald-600 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <MessageSquare className="w-3.5 h-3.5" />
              <span>واتساب (WhatsApp)</span>
            </button>

            <button
              onClick={() => {
                setChannel('sms');
                setIsAutoPlaying(false);
              }}
              type="button"
              className={`flex items-center gap-1.5 px-3 py-1 rounded-md text-xs font-bold transition-all ${
                channel === 'sms'
                  ? 'bg-sky-600 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Smartphone className="w-3.5 h-3.5" />
              <span>رسائل SMS قصيرة</span>
            </button>
          </div>
        </div>

        {/* Progress Bar */}
        <div className="w-full bg-slate-100 h-2 relative">
          <div
            className={`h-2 transition-all duration-300 ${
              channel === 'whatsapp' ? 'bg-emerald-600' : 'bg-sky-600'
            }`}
            style={{
              width: `${Math.min(100, Math.round(((currentIndex) / totalCount) * 100))}%`,
            }}
          />
        </div>

        {/* Content Body */}
        {isFinished ? (
          /* Finished State */
          <div className="p-8 text-center space-y-4">
            <div
              className={`w-16 h-16 rounded-full flex items-center justify-center mx-auto shadow-inner ${
                channel === 'whatsapp' ? 'bg-emerald-100 text-emerald-600' : 'bg-sky-100 text-sky-600'
              }`}
            >
              <CheckCircle2 className="w-9 h-9" />
            </div>
            <div>
              <h4 className="text-base font-bold text-slate-900">
                تم الانتهاء من إرسال كافة الرسائل بنجاح عبر {channel === 'whatsapp' ? 'واتساب' : 'SMS'}!
              </h4>
              <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
                تم استعراض وإرسال {totalCount} رسالة وتحديث مؤشر الحالة الخاص بكل رسالة.
              </p>
            </div>
            <div className="pt-2">
              <button
                onClick={onClose}
                type="button"
                className={`px-6 py-2.5 text-xs font-bold text-white rounded-xl shadow-sm transition-all ${
                  channel === 'whatsapp' ? 'bg-emerald-600 hover:bg-emerald-700' : 'bg-sky-600 hover:bg-sky-700'
                }`}
              >
                العودة للشاشة الرئيسية
              </button>
            </div>
          </div>
        ) : (
          /* Active Sender View */
          <div className="p-6 space-y-5">
            {/* Top Counter & Delay Bar */}
            <div className="flex items-center justify-between gap-3 text-xs">
              <div className="flex items-center gap-1.5">
                <span className="text-slate-500">الرسالة الحالية:</span>
                <span className={`font-mono font-bold text-sm ${channel === 'whatsapp' ? 'text-emerald-700' : 'text-sky-700'}`}>
                  {currentIndex + 1}
                </span>
                <span className="text-slate-400">من</span>
                <span className="font-mono font-bold text-slate-800 text-sm">
                  {totalCount}
                </span>
              </div>

              {/* Delay selector */}
              <div className="flex items-center gap-2 bg-slate-50 border border-slate-200 px-3 py-1.5 rounded-lg">
                <Clock className="w-3.5 h-3.5 text-slate-400" />
                <span className="text-slate-600">الفاصل الزمني:</span>
                <select
                  value={intervalSeconds}
                  onChange={(e) => setIntervalSeconds(Number(e.target.value))}
                  disabled={isAutoPlaying}
                  className="bg-white border border-slate-300 rounded px-1.5 py-0.5 font-mono font-semibold text-slate-800 text-xs"
                >
                  <option value={3}>3 ثوانٍ</option>
                  <option value={4}>4 ثوانٍ</option>
                  <option value={6}>6 ثوانٍ</option>
                  <option value={8}>8 ثوانٍ</option>
                </select>
              </div>
            </div>

            {/* Current Item Card */}
            {currentItem && (
              <div className="bg-slate-50/80 rounded-2xl border border-slate-200 p-4 space-y-3">
                {/* Meta details */}
                <div className="flex items-center justify-between border-b border-slate-200/60 pb-3">
                  <div>
                    <span className="text-[11px] text-slate-400 block">المستلم:</span>
                    <span className="text-sm font-bold text-slate-900">
                      {currentItem.clientName || 'عميل غير مسجل'}
                    </span>
                  </div>

                  <div className="text-left" dir="ltr">
                    <span className="text-[11px] text-slate-400 block">رقم الهاتف:</span>
                    <span className="font-mono font-bold text-slate-800 text-sm">
                      {currentItem.phoneFull || currentItem.phone}
                    </span>
                  </div>

                  {currentItem.totalAccount && (
                    <div className="text-left">
                      <span className="text-[11px] text-slate-400 block">الرصيد:</span>
                      <span className="font-mono font-bold text-emerald-700 text-xs">
                        {currentItem.totalAccount}
                      </span>
                    </div>
                  )}
                </div>

                {/* Message Body */}
                <div>
                  <span className="text-[11px] font-semibold text-slate-500 mb-1 block">
                    نص الرسالة التي ستُرسل عبر {channel === 'whatsapp' ? 'واتساب' : 'SMS'}:
                  </span>
                  <div className="bg-white p-3.5 rounded-xl border border-slate-200 text-xs text-slate-700 whitespace-pre-wrap leading-relaxed max-h-40 overflow-y-auto font-sans">
                    {currentItem.rawMsg}
                  </div>
                </div>

                {/* Status Indicator */}
                <div className="flex items-center justify-between text-xs text-slate-500 pt-1">
                  <span>
                    حالة {channel === 'whatsapp' ? 'واتساب' : 'SMS'}:{' '}
                    {isCurrentSent ? (
                      <span className="text-emerald-700 font-semibold">✓ تم إرسالها سابقاً</span>
                    ) : (
                      <span className="text-amber-700 font-semibold">قيد الانتظار</span>
                    )}
                  </span>

                  {isAutoPlaying && (
                    <span className="inline-flex items-center gap-1.5 font-mono text-emerald-700 font-bold bg-emerald-100/70 px-2 py-0.5 rounded-full animate-pulse">
                      <span>إرسال تلقائي بعد</span>
                      <span className="text-sm">{countdown}s</span>
                    </span>
                  )}
                </div>
              </div>
            )}

            {/* Controls: Manual Step or Auto Play */}
            <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-2">
              <div className="flex items-center gap-2 w-full sm:w-auto">
                {/* Auto Play / Pause Toggle Button */}
                <button
                  onClick={toggleAutoPlay}
                  type="button"
                  className={`flex-1 sm:flex-initial flex items-center justify-center gap-1.5 px-4 py-2.5 text-xs font-bold rounded-xl transition-all ${
                    isAutoPlaying
                      ? 'bg-amber-600 hover:bg-amber-700 text-white'
                      : 'bg-slate-900 hover:bg-slate-800 text-white'
                  }`}
                >
                  {isAutoPlaying ? (
                    <>
                      <Pause className="w-4 h-4" />
                      <span>إيقاف التشغيل التلقائي</span>
                    </>
                  ) : (
                    <>
                      <Play className="w-4 h-4 fill-white" />
                      <span>تشغيل إرسال تلقائي</span>
                    </>
                  )}
                </button>

                {/* Skip button */}
                <button
                  onClick={handleSkip}
                  type="button"
                  className="px-3 py-2.5 text-xs font-medium text-slate-600 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 rounded-xl transition-colors"
                  title="تخطي هذه الرسالة"
                >
                  <SkipForward className="w-4 h-4" />
                </button>
              </div>

              {/* Main Manual Action: Send current & advance */}
              <button
                onClick={handleManualSendAndNext}
                type="button"
                className={`w-full sm:w-auto flex items-center justify-center gap-2 px-6 py-2.5 text-xs font-bold text-white rounded-xl shadow-md transition-all active:scale-[0.98] ${
                  channel === 'whatsapp'
                    ? 'bg-emerald-600 hover:bg-emerald-700'
                    : 'bg-sky-600 hover:bg-sky-700'
                }`}
              >
                <Send className="w-4 h-4" />
                <span>إرسال عبر {channel === 'whatsapp' ? 'واتساب' : 'SMS'} والتالي</span>
                <ExternalLink className="w-3.5 h-3.5 opacity-75" />
              </button>
            </div>
          </div>
        )}

        {/* Footer info tip */}
        <div className="px-6 py-3 bg-slate-50 border-t border-slate-200 text-[11px] text-slate-500 flex items-center gap-2">
          <AlertCircle className="w-3.5 h-3.5 text-slate-500 shrink-0" />
          <span>
            {channel === 'whatsapp'
              ? 'يتم فتح تطبيق أو ويب واتساب مع الرسالة جاهزة.'
              : 'يتم فتح تطبيق الرسائل النصية القصيرة SMS مع رقم المستلم ونص الرسالة جاهزاً.'}
          </span>
        </div>
      </div>
    </div>
  );
};
