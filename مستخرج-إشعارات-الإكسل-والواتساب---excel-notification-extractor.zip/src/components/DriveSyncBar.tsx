import React from 'react';
import {
  HardDrive,
  RefreshCw,
  Bell,
  CheckCircle2,
  Clock,
  Sparkles,
  X
} from 'lucide-react';

interface DriveSyncBarProps {
  boundFileName: string | null;
  boundFileId: string | null;
  isSyncing: boolean;
  lastSyncTime: Date | null;
  autoSyncEnabled: boolean;
  onToggleAutoSync: () => void;
  onManualSync: () => void;
  onOpenDriveModal: () => void;
  newNotificationsCount: number;
  onClearNewAlert: () => void;
}

export const DriveSyncBar: React.FC<DriveSyncBarProps> = ({
  boundFileName,
  boundFileId,
  isSyncing,
  lastSyncTime,
  autoSyncEnabled,
  onToggleAutoSync,
  onManualSync,
  onOpenDriveModal,
  newNotificationsCount,
  onClearNewAlert,
}) => {
  return (
    <div className="space-y-3">
      {/* Alert Banner when new notifications arrive from Drive sync */}
      {newNotificationsCount > 0 && (
        <div className="bg-emerald-600 text-white p-3.5 rounded-xl shadow-md flex items-center justify-between gap-3 animate-in slide-in-from-top-2 duration-300">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-emerald-500 flex items-center justify-center shrink-0">
              <Bell className="w-4 h-4 text-white animate-bounce" />
            </div>
            <div>
              <div className="text-xs font-bold flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5" />
                <span>تم رصد تحديث جديد على Google Drive!</span>
              </div>
              <p className="text-[11px] text-emerald-100 mt-0.5">
                وصلت <span className="font-bold underline">{newNotificationsCount}</span> إشعار جديد في الكشف وتمت مزامنتها تلقائياً.
              </p>
            </div>
          </div>

          <button
            onClick={onClearNewAlert}
            className="p-1 rounded-md hover:bg-emerald-700 text-emerald-100 hover:text-white transition-colors"
            title="إغلاق الإشعار"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Main Drive Sync Widget Card */}
      <div className="bg-white rounded-xl border border-slate-200 p-3.5 shadow-xs flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div
            className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 transition-colors ${
              boundFileId ? 'bg-blue-600 text-white shadow-xs' : 'bg-slate-100 text-slate-500'
            }`}
          >
            <HardDrive className="w-4 h-4" />
          </div>

          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-slate-900">
                {boundFileId ? (
                  <>
                    <span>ملف المزامنة الحية (Google Drive):</span>{' '}
                    <span className="text-blue-700 font-mono underline">{boundFileName}</span>
                  </>
                ) : (
                  'ربط ملف من Google Drive للمزامنة الحية'
                )}
              </span>

              {boundFileId && (
                <span className="inline-flex items-center gap-1 text-[10px] font-semibold text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded-full">
                  <CheckCircle2 className="w-3 h-3" />
                  <span>متصل ومثبت</span>
                </span>
              )}
            </div>

            <p className="text-[11px] text-slate-500 mt-0.5 flex items-center gap-1">
              <Clock className="w-3 h-3 text-slate-400" />
              {lastSyncTime ? (
                <>
                  آخر فحص للملف:{' '}
                  <span className="font-mono text-slate-700" dir="ltr">
                    {lastSyncTime.toLocaleTimeString('ar-EG')}
                  </span>
                </>
              ) : (
                'اختر ملفاً ليقوم التطبيق بمراقبته وتحديث إشعاراته تلقائياً'
              )}
            </p>
          </div>
        </div>

        {/* Sync Controls & Drive Modal Button */}
        <div className="flex items-center flex-wrap gap-2">
          {boundFileId && (
            <>
              {/* Auto Sync Toggle */}
              <button
                onClick={onToggleAutoSync}
                type="button"
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold border transition-colors ${
                  autoSyncEnabled
                    ? 'bg-blue-50 text-blue-700 border-blue-200 hover:bg-blue-100'
                    : 'bg-slate-100 text-slate-600 border-slate-200 hover:bg-slate-200'
                }`}
                title="تفعيل أو إيقاف الفحص التلقائي المستمر كل 30 ثانية"
              >
                {autoSyncEnabled ? 'المزامنة التلقائية: مفعلة ✓' : 'المزامنة التلقائية: متوقفة'}
              </button>

              {/* Manual Sync Now */}
              <button
                onClick={onManualSync}
                disabled={isSyncing}
                type="button"
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-white hover:bg-slate-50 text-slate-700 border border-slate-300 transition-colors shadow-2xs"
                title="فحص فوري الآن لجوجل درايف بحثاً عن أي تحديثات"
              >
                <RefreshCw className={`w-3.5 h-3.5 text-blue-600 ${isSyncing ? 'animate-spin' : ''}`} />
                <span>{isSyncing ? 'جاري الفحص...' : 'مزامنة الآن'}</span>
              </button>
            </>
          )}

          {/* Connect / Change File Button */}
          <button
            onClick={onOpenDriveModal}
            type="button"
            className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 transition-colors shadow-2xs"
          >
            <HardDrive className="w-3.5 h-3.5" />
            <span>{boundFileId ? 'تغيير الملف المحدد' : 'اختيار ملف من Google Drive'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
