import React, { useRef, useState } from 'react';
import { UploadCloud, FileSpreadsheet, SlidersHorizontal, Check, AlertCircle } from 'lucide-react';
import * as XLSX from 'xlsx';
import { ColumnMapping, detectColumns } from '../utils/excelParser';

interface FileUploaderProps {
  onFileParsed: (data: Record<string, any>[], fileName: string, detectedMapping: ColumnMapping) => void;
  availableHeaders: string[];
  columnMapping: ColumnMapping;
  onMappingChange: (newMapping: ColumnMapping) => void;
  countryCode: string;
  onCountryCodeChange: (code: string) => void;
  currentFileName: string;
}

export const FileUploader: React.FC<FileUploaderProps> = ({
  onFileParsed,
  availableHeaders,
  columnMapping,
  onMappingChange,
  countryCode,
  onCountryCodeChange,
  currentFileName,
}) => {
  const [isDragging, setIsDragging] = useState(false);
  const [isConfigOpen, setIsConfigOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const processFile = async (file: File) => {
    setIsLoading(true);
    setErrorMsg(null);
    try {
      const buffer = await file.arrayBuffer();
      const workbook = XLSX.read(buffer, { type: 'array', cellDates: true });
      
      const firstSheetName = workbook.SheetNames[0];
      if (!firstSheetName) {
        throw new Error('الملف لا يحتوي على أوراق عمل صالحة.');
      }

      const worksheet = workbook.Sheets[firstSheetName];
      const jsonData = XLSX.utils.sheet_to_json<Record<string, any>>(worksheet, { defval: '' });

      if (jsonData.length === 0) {
        throw new Error('الملف فارغ، لم يتم العثور على أي صفوف بيانات.');
      }

      // Extract headers from first row
      const headers = Object.keys(jsonData[0] || {});
      const detected = detectColumns(headers);

      onFileParsed(jsonData, file.name, detected);
    } catch (err: any) {
      console.error(err);
      setErrorMsg(err.message || 'حدث خطأ أثناء قراءة ملف الإكسل. يرجى التأكد من صحة الملف.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const files = e.dataTransfer.files;
    if (files && files.length > 0) {
      processFile(files[0]);
    }
  };

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files.length > 0) {
      processFile(files[0]);
    }
  };

  return (
    <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs transition-all">
      <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-4">
        {/* Upload Dropzone */}
        <div
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          onDrop={handleDrop}
          onClick={() => fileInputRef.current?.click()}
          className={`flex-1 flex items-center gap-4 p-4 rounded-lg border-2 border-dashed cursor-pointer transition-all ${
            isDragging
              ? 'border-emerald-500 bg-emerald-50/60'
              : 'border-slate-300 hover:border-emerald-400 bg-slate-50/50 hover:bg-slate-50'
          }`}
        >
          <input
            ref={fileInputRef}
            type="file"
            accept=".xlsx, .xls, .csv"
            onChange={handleFileInput}
            className="hidden"
          />

          <div className="w-11 h-11 rounded-lg bg-emerald-100/80 text-emerald-700 flex items-center justify-center shrink-0">
            {isLoading ? (
              <div className="w-5 h-5 border-2 border-emerald-600 border-t-transparent rounded-full animate-spin" />
            ) : (
              <UploadCloud className="w-6 h-6" />
            )}
          </div>

          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-2">
              <span className="text-sm font-semibold text-slate-800 truncate">
                {currentFileName ? currentFileName : 'اختر ملف إكسل أو قم بإفلاته هنا'}
              </span>
              {currentFileName && (
                <span className="text-[11px] font-medium text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded-full shrink-0">
                  ملف نشط
                </span>
              )}
            </div>
            <p className="text-xs text-slate-500 mt-0.5 truncate">
              يدعم ملفات XLSX, XLS, CSV (مثل ملف حنححخه.xlsx والأعمدة: المستلم، الرسالة، الوقت)
            </p>
          </div>

          <button
            type="button"
            className="hidden sm:inline-flex items-center px-3.5 py-1.5 text-xs font-semibold text-slate-700 bg-white border border-slate-300 rounded-md hover:bg-slate-100 transition-colors shrink-0"
          >
            تصفح الملفات
          </button>
        </div>

        {/* Quick Settings & Column Mapping Toggle */}
        <div className="flex items-center gap-3 shrink-0">
          <div className="flex items-center gap-1.5 bg-slate-50 border border-slate-200 px-3 py-2 rounded-lg text-xs">
            <span className="text-slate-500">مفتاح الدولة:</span>
            <input
              type="text"
              value={countryCode}
              onChange={(e) => onCountryCodeChange(e.target.value.replace(/[^\d]/g, ''))}
              placeholder="967"
              className="w-14 text-center font-mono font-medium text-slate-900 bg-white border border-slate-300 rounded px-1.5 py-0.5 focus:outline-emerald-500"
              title="رمز الدولة المضاف لأرقام الـ 9 أرقام (افتراضياً 967 لليمن)"
            />
          </div>

          {availableHeaders.length > 0 && (
            <button
              onClick={() => setIsConfigOpen(!isConfigOpen)}
              type="button"
              className={`flex items-center gap-1.5 px-3 py-2 text-xs font-medium rounded-lg border transition-colors ${
                isConfigOpen
                  ? 'bg-slate-900 text-white border-slate-900'
                  : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-50'
              }`}
            >
              <SlidersHorizontal className="w-3.5 h-3.5" />
              <span>مطابقة الأعمدة</span>
            </button>
          )}
        </div>
      </div>

      {/* Error alert if any */}
      {errorMsg && (
        <div className="mt-3 p-3 bg-red-50 border border-red-200 rounded-lg flex items-center gap-2 text-xs text-red-700">
          <AlertCircle className="w-4 h-4 shrink-0 text-red-600" />
          <span>{errorMsg}</span>
        </div>
      )}

      {/* Column Mapping Collapsible */}
      {isConfigOpen && availableHeaders.length > 0 && (
        <div className="mt-4 pt-4 border-t border-slate-100">
          <div className="flex items-center justify-between mb-3">
            <h4 className="text-xs font-semibold text-slate-800">
              تحديد أعمدة ملف الإكسل (تم الكشف التلقائي عنها):
            </h4>
            <span className="text-[11px] text-slate-400">
              يمكنك التعديل في حال كانت أسماء الأعمدة مختلفة
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="block text-[11px] font-medium text-slate-600 mb-1">
                عمود رقم الهاتف (المستلم):
              </label>
              <select
                value={columnMapping.phoneCol}
                onChange={(e) => onMappingChange({ ...columnMapping, phoneCol: e.target.value })}
                className="w-full text-xs bg-slate-50 border border-slate-300 rounded-md p-2 font-medium text-slate-800 focus:bg-white focus:outline-emerald-500"
              >
                {availableHeaders.map((h) => (
                  <option key={h} value={h}>
                    {h}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-[11px] font-medium text-slate-600 mb-1">
                عمود نص الإشعار (الرسالة):
              </label>
              <select
                value={columnMapping.msgCol}
                onChange={(e) => onMappingChange({ ...columnMapping, msgCol: e.target.value })}
                className="w-full text-xs bg-slate-50 border border-slate-300 rounded-md p-2 font-medium text-slate-800 focus:bg-white focus:outline-emerald-500"
              >
                {availableHeaders.map((h) => (
                  <option key={h} value={h}>
                    {h}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-[11px] font-medium text-slate-600 mb-1">
                عمود تاريخ ووقت الحركة (الوقت):
              </label>
              <select
                value={columnMapping.timeCol}
                onChange={(e) => onMappingChange({ ...columnMapping, timeCol: e.target.value })}
                className="w-full text-xs bg-slate-50 border border-slate-300 rounded-md p-2 font-medium text-slate-800 focus:bg-white focus:outline-emerald-500"
              >
                {availableHeaders.map((h) => (
                  <option key={h} value={h}>
                    {h}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
