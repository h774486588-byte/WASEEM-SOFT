import React, { useState, useEffect } from 'react';
import {
  X,
  Search,
  RefreshCw,
  FileSpreadsheet,
  Check,
  HardDrive,
  LogOut,
  AlertCircle,
  ExternalLink,
  Clock,
  Link as LinkIcon,
  ShieldAlert
} from 'lucide-react';
import { googleSignIn, logout, AuthUser } from '../services/googleAuth';
import { listDriveFiles, DriveFileItem } from '../services/googleDrive';

interface GoogleDriveModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: AuthUser | null;
  accessToken: string | null;
  onAuthSuccess: (user: AuthUser, token: string) => void;
  onFileSelected: (file: DriveFileItem) => void;
  selectedFileId: string | null;
}

export const GoogleDriveModal: React.FC<GoogleDriveModalProps> = ({
  isOpen,
  onClose,
  currentUser,
  accessToken,
  onAuthSuccess,
  onFileSelected,
  selectedFileId,
}) => {
  const [activeTab, setActiveTab] = useState<'account' | 'direct_link'>('account');
  const [files, setFiles] = useState<DriveFileItem[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isSigningIn, setIsSigningIn] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [isPopupBlocked, setIsPopupBlocked] = useState(false);

  // Direct Link state
  const [directLinkInput, setDirectLinkInput] = useState('');
  const [isCheckingDirectLink, setIsCheckingDirectLink] = useState(false);

  // Fetch files when user is authenticated
  const loadFiles = async (token: string, query: string = '') => {
    setIsLoading(true);
    setErrorMsg(null);
    try {
      const driveFiles = await listDriveFiles(token, query);
      setFiles(driveFiles);
    } catch (err: any) {
      console.error(err);
      setErrorMsg(err.message || 'فشل جلب الملفات من Google Drive');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if (isOpen && accessToken) {
      loadFiles(accessToken, searchQuery);
    }
  }, [isOpen, accessToken]);

  const handleSignIn = async () => {
    setIsSigningIn(true);
    setErrorMsg(null);
    setIsPopupBlocked(false);
    try {
      const res = await googleSignIn();
      if (res) {
        onAuthSuccess(res.user, res.accessToken);
        loadFiles(res.accessToken, searchQuery);
      }
    } catch (err: any) {
      const msg = err.message || 'فشل تسجيل الدخول باستخدام حساب Google';
      setErrorMsg(msg);
      if (msg.includes('منبثقة') || msg.toLowerCase().includes('popup')) {
        setIsPopupBlocked(true);
      }
    } finally {
      setIsSigningIn(false);
    }
  };

  const handleSignOut = async () => {
    await logout();
    setFiles([]);
  };

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (accessToken) {
      loadFiles(accessToken, searchQuery);
    }
  };

  // Parse Google Drive Link / ID
  const handleDirectLinkSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!directLinkInput.trim()) return;

    setIsCheckingDirectLink(true);
    try {
      let fileId = directLinkInput.trim();

      // Extract ID from full URL if pasted
      const sheetsMatch = directLinkInput.match(/\/spreadsheets\/d\/([a-zA-Z0-9-_]+)/);
      const driveFileMatch = directLinkInput.match(/\/file\/d\/([a-zA-Z0-9-_]+)/);
      const idParamMatch = directLinkInput.match(/[?&]id=([a-zA-Z0-9-_]+)/);

      if (sheetsMatch) {
        fileId = sheetsMatch[1];
      } else if (driveFileMatch) {
        fileId = driveFileMatch[1];
      } else if (idParamMatch) {
        fileId = idParamMatch[1];
      }

      const syntheticFile: DriveFileItem = {
        id: fileId,
        name: `كشف Google Drive (${fileId.slice(0, 8)}...)`,
        mimeType: directLinkInput.includes('spreadsheets')
          ? 'application/vnd.google-apps.spreadsheet'
          : 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        modifiedTime: new Date().toISOString(),
      };

      onFileSelected(syntheticFile);
      onClose();
    } catch (err: any) {
      setErrorMsg('تعذر استخراج معرف الملف من الرابط المدخل');
    } finally {
      setIsCheckingDirectLink(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-2xl overflow-hidden animate-in fade-in duration-200 flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="px-5 py-4 border-b border-slate-200 bg-slate-50 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-600 text-white flex items-center justify-center shadow-xs">
              <HardDrive className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900">
                تحديد ملف الإشعارات من Google Drive والمزامنة التلقائية
              </h3>
              <p className="text-xs text-slate-500">
                حفظ الملف للمزامنة الحية وإشعارك فور وصول تحديثات جديدة
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-600 p-1.5 rounded-lg hover:bg-slate-200/60 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Tab Selection */}
        <div className="px-5 py-2.5 bg-slate-100/80 border-b border-slate-200 flex items-center gap-2">
          <button
            onClick={() => setActiveTab('account')}
            type="button"
            className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-all ${
              activeTab === 'account'
                ? 'bg-white text-blue-700 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            استعراض ملفات حساب Google
          </button>

          <button
            onClick={() => setActiveTab('direct_link')}
            type="button"
            className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold rounded-lg transition-all ${
              activeTab === 'direct_link'
                ? 'bg-white text-blue-700 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <LinkIcon className="w-3.5 h-3.5" />
            <span>ربط مباشر عبر رابط / معرّف الملف</span>
          </button>
        </div>

        {/* Content Body */}
        <div className="p-5 flex-1 overflow-y-auto space-y-4">
          {/* Popup Blocker Notice */}
          {isPopupBlocked && (
            <div className="p-4 bg-amber-50 border border-amber-200 rounded-xl flex items-start gap-3 text-xs text-amber-900">
              <ShieldAlert className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
              <div className="space-y-1">
                <p className="font-bold">المتصفح قام بحظر النافذة المنبثقة (Popup Blocked):</p>
                <p className="text-amber-800 leading-relaxed">
                  للسماح بالنافذة: انقر على أيقونة النافذة المنبثقة الصغيرة في أقصى يمين شريط عنوان المتصفح (Address Bar)، واختر <strong>"السماح دائماً بالنوافذ المنبثقة لهذا الموقع"</strong> ثم اضغط على زر تسجيل الدخول مرة أخرى.
                </p>
              </div>
            </div>
          )}

          {errorMsg && !isPopupBlocked && (
            <div className="p-3 bg-red-50 border border-red-200 rounded-xl flex items-center gap-2 text-xs text-red-700">
              <AlertCircle className="w-4 h-4 text-red-600 shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}

          {activeTab === 'account' ? (
            /* Account Tab */
            currentUser && accessToken ? (
              <>
                {/* Profile info */}
                <div className="px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl flex items-center justify-between gap-3 text-xs">
                  <div className="flex items-center gap-2.5">
                    {currentUser.photoURL ? (
                      <img
                        src={currentUser.photoURL}
                        alt=""
                        className="w-7 h-7 rounded-full border border-slate-300"
                      />
                    ) : (
                      <div className="w-7 h-7 rounded-full bg-blue-100 text-blue-700 flex items-center justify-center font-bold">
                        {currentUser.displayName?.charAt(0) || 'U'}
                      </div>
                    )}
                    <div>
                      <span className="font-semibold text-slate-800 block">
                        {currentUser.displayName || currentUser.email}
                      </span>
                      {currentUser.email && (
                        <span className="text-[11px] text-slate-500 font-mono" dir="ltr">
                          {currentUser.email}
                        </span>
                      )}
                    </div>
                  </div>

                  <button
                    onClick={handleSignOut}
                    type="button"
                    className="flex items-center gap-1 text-slate-500 hover:text-red-600 px-2.5 py-1 rounded-md hover:bg-white transition-colors"
                  >
                    <LogOut className="w-3.5 h-3.5" />
                    <span>خروج</span>
                  </button>
                </div>

                {/* Search input & Refresh */}
                <form onSubmit={handleSearch} className="flex items-center gap-2">
                  <div className="relative flex-1">
                    <Search className="w-4 h-4 absolute right-3 top-1/2 -translate-y-1/2 text-slate-400" />
                    <input
                      type="text"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      placeholder="ابحث عن ملف الإكسل في Google Drive (مثال: حنححخه)..."
                      className="w-full text-xs pr-9 pl-3 py-2 bg-slate-50 hover:bg-white focus:bg-white border border-slate-300 rounded-lg text-slate-800 focus:outline-blue-500 transition-colors"
                    />
                  </div>

                  <button
                    type="submit"
                    className="px-4 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg transition-colors whitespace-nowrap"
                  >
                    بحث
                  </button>

                  <button
                    onClick={() => loadFiles(accessToken, searchQuery)}
                    type="button"
                    className="p-2 text-slate-600 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors"
                    title="تحديث قائمة الملفات"
                  >
                    <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin' : ''}`} />
                  </button>
                </form>

                {/* Files List */}
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-xs text-slate-500 font-semibold px-1">
                    <span>ملفات الإكسل وجداول البيانات المتوفرة:</span>
                    <span>{files.length} ملف</span>
                  </div>

                  {isLoading ? (
                    <div className="py-12 text-center text-slate-400 text-xs">
                      <RefreshCw className="w-6 h-6 animate-spin mx-auto mb-2 text-blue-600" />
                      <span>جاري فحص ملفات Google Drive...</span>
                    </div>
                  ) : files.length === 0 ? (
                    <div className="py-10 text-center text-slate-500 bg-slate-50 rounded-xl border border-slate-200 p-6 text-xs">
                      <FileSpreadsheet className="w-8 h-8 text-slate-400 mx-auto mb-2" />
                      <p className="font-semibold text-slate-700">لم يتم العثور على ملفات إكسل أو جداول بيانات</p>
                      <p className="text-[11px] text-slate-400 mt-1">
                        تأكد من وجود ملفات بصيغة .xlsx أو .csv أو Google Sheets في حسابك.
                      </p>
                    </div>
                  ) : (
                    <div className="space-y-2 max-h-[350px] overflow-y-auto pr-1">
                      {files.map((file) => {
                        const isSelected = selectedFileId === file.id;

                        return (
                          <div
                            key={file.id}
                            className={`p-3.5 rounded-xl border transition-all flex items-center justify-between gap-3 ${
                              isSelected
                                ? 'bg-blue-50/80 border-blue-500 ring-2 ring-blue-500/20'
                                : 'bg-white border-slate-200 hover:border-blue-300 hover:bg-slate-50/80'
                            }`}
                          >
                            <div className="flex items-center gap-3 min-w-0">
                              <div className="w-9 h-9 rounded-lg bg-emerald-100 text-emerald-700 flex items-center justify-center shrink-0">
                                <FileSpreadsheet className="w-5 h-5" />
                              </div>
                              <div className="min-w-0">
                                <div className="flex items-center gap-2">
                                  <span className="text-xs font-bold text-slate-800 truncate" title={file.name}>
                                    {file.name}
                                  </span>
                                  {isSelected && (
                                    <span className="text-[10px] font-semibold text-blue-700 bg-blue-100 px-2 py-0.2 rounded-full shrink-0">
                                      الملف النشط حالياً
                                    </span>
                                  )}
                                </div>
                                <div className="flex items-center gap-2 text-[11px] text-slate-400 mt-0.5">
                                  <span className="flex items-center gap-1 font-mono">
                                    <Clock className="w-3 h-3" />
                                    آخر تعديل:{' '}
                                    {file.modifiedTime
                                      ? new Date(file.modifiedTime).toLocaleString('ar-EG')
                                      : '—'}
                                  </span>
                                </div>
                              </div>
                            </div>

                            <button
                              onClick={() => {
                                onFileSelected(file);
                                onClose();
                              }}
                              type="button"
                              className={`px-3.5 py-1.5 text-xs font-bold rounded-lg transition-all shrink-0 ${
                                isSelected
                                  ? 'bg-blue-600 text-white shadow-xs'
                                  : 'bg-slate-100 hover:bg-blue-600 hover:text-white text-slate-700'
                              }`}
                            >
                              {isSelected ? 'تحديث المزامنة' : 'اختيار وتثبيت'}
                            </button>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>
              </>
            ) : (
              <div className="py-10 text-center space-y-3">
                <div className="w-14 h-14 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center mx-auto">
                  <HardDrive className="w-7 h-7" />
                </div>
                <h4 className="text-sm font-bold text-slate-800">
                  ربط ملف إكسل من Google Drive للمزامنة الفورية
                </h4>
                <p className="text-xs text-slate-500 max-w-sm mx-auto leading-relaxed">
                  سجل الدخول بحساب Google لاختيار الملف المطلوب ليقوم التطبيق بمراقبته وتحديث الإشعارات فورياً.
                </p>
                <div className="pt-2">
                  <button
                    onClick={handleSignIn}
                    disabled={isSigningIn}
                    type="button"
                    className="inline-flex items-center gap-2 px-5 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold shadow-md transition-all active:scale-[0.98]"
                  >
                    <svg className="w-4 h-4" viewBox="0 0 24 24">
                      <path
                        fill="#4285F4"
                        d="M23.745 12.27c0-.7-.06-1.4-.19-2.07H12v4.51h6.6c-.29 1.52-1.14 2.8-2.4 3.66v3.02h3.87c2.26-2.09 3.67-5.17 3.67-9.12z"
                      />
                      <path
                        fill="#34A853"
                        d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.87-3.02c-1.08.72-2.45 1.16-4.06 1.16-3.13 0-5.78-2.11-6.73-4.96H1.27v3.12C3.26 21.36 7.35 24 12 24z"
                      />
                      <path
                        fill="#FBBC05"
                        d="M5.27 14.27c-.25-.72-.38-1.49-.38-2.27s.13-1.55.38-2.27V6.61H1.27C.46 8.23 0 10.06 0 12s.46 3.77 1.27 5.39l4-3.12z"
                      />
                      <path
                        fill="#EA4335"
                        d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.35 0 3.26 2.64 1.27 6.61l4 3.12c.95-2.85 3.6-4.98 6.73-4.98z"
                      />
                    </svg>
                    <span>{isSigningIn ? 'جاري فتح النافذة...' : 'تسجيل الدخول باستخدام Google'}</span>
                  </button>
                </div>
              </div>
            )
          ) : (
            /* Direct Link Tab */
            <div className="space-y-4 py-2">
              <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 text-xs text-slate-700 space-y-2">
                <span className="font-bold flex items-center gap-1.5 text-blue-700">
                  <LinkIcon className="w-4 h-4" />
                  ربط سريع باستخدام رابط الملف أو معرّف Drive:
                </span>
                <p className="text-slate-500 leading-relaxed text-[11px]">
                  يمكنك لصق رابط مشاركة ملف الإكسل أو جدول بيانات Google Sheets أو معرّف الملف (File ID) مباشرة لتثبيته للمزامنة.
                </p>
              </div>

              <form onSubmit={handleDirectLinkSubmit} className="space-y-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    رابط ملف Google Drive أو Google Sheets:
                  </label>
                  <input
                    type="text"
                    value={directLinkInput}
                    onChange={(e) => setDirectLinkInput(e.target.value)}
                    placeholder="https://docs.google.com/spreadsheets/d/... أو https://drive.google.com/file/d/..."
                    className="w-full text-xs px-3.5 py-2.5 bg-slate-50 hover:bg-white focus:bg-white border border-slate-300 rounded-xl text-slate-800 focus:outline-blue-500 transition-colors font-mono"
                    dir="ltr"
                  />
                </div>

                <div className="flex justify-end pt-2">
                  <button
                    type="submit"
                    disabled={!directLinkInput.trim() || isCheckingDirectLink}
                    className="px-5 py-2 text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 disabled:opacity-50 rounded-xl shadow-xs transition-all"
                  >
                    {isCheckingDirectLink ? 'جاري الفحص...' : 'تثبيت ومزامنة هذا الملف'}
                  </button>
                </div>
              </form>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-5 py-3.5 bg-slate-50 border-t border-slate-200 flex items-center justify-between text-xs text-slate-500">
          <span>يتم حفظ اختيارك للملف في المتصفح لضمان المزامنة التلقائية دائماً.</span>
          <button
            onClick={onClose}
            type="button"
            className="px-3.5 py-1.5 text-xs font-medium text-slate-600 hover:text-slate-800"
          >
            إغلاق
          </button>
        </div>
      </div>
    </div>
  );
};
