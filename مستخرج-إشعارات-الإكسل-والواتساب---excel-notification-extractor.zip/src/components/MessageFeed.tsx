import React, { useState } from 'react';
import {
  Send,
  Copy,
  Check,
  ExternalLink,
  MessageSquare,
  Smartphone,
  CheckCircle,
  Clock,
  CheckSquare,
  Square,
  Phone,
  DollarSign
} from 'lucide-react';
import { ProcessedNotification } from '../utils/excelParser';
import { ChannelStatusBadge } from './ChannelStatusBadge';

interface MessageFeedProps {
  notifications: ProcessedNotification[];
  selectedIds: Set<string>;
  onToggleSelect: (id: string) => void;
  onSelectAll: () => void;
  onDeselectAll: () => void;
  onToggleWhatsAppStatus: (id: string) => void;
  onToggleSmsStatus: (id: string) => void;
  onSingleSendWhatsApp: (item: ProcessedNotification) => void;
  onSingleSendSms: (item: ProcessedNotification) => void;
  onStartBatchSend: (channel: 'whatsapp' | 'sms') => void;
}

export const MessageFeed: React.FC<MessageFeedProps> = ({
  notifications,
  selectedIds,
  onToggleSelect,
  onSelectAll,
  onDeselectAll,
  onToggleWhatsAppStatus,
  onToggleSmsStatus,
  onSingleSendWhatsApp,
  onSingleSendSms,
  onStartBatchSend,
}) => {
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const isAllSelected =
    notifications.length > 0 && notifications.every((n) => selectedIds.has(n.id));
  const someSelected = notifications.some((n) => selectedIds.has(n.id));
  const selectedCount = notifications.filter((n) => selectedIds.has(n.id)).length;

  const handleCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 1800);
  };

  if (notifications.length === 0) {
    return null;
  }

  return (
    <div className="space-y-4">
      {/* Top Feed Actions Bar */}
      <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-xs flex flex-wrap items-center justify-between gap-3 sticky top-16 z-20 backdrop-blur-md bg-white/95">
        {/* Select All Checkbox Control */}
        <div className="flex items-center gap-3">
          <button
            onClick={isAllSelected ? onDeselectAll : onSelectAll}
            type="button"
            className="flex items-center gap-2 text-xs font-bold text-slate-800 hover:text-emerald-700 transition-colors select-none"
          >
            {isAllSelected ? (
              <CheckSquare className="w-5 h-5 text-emerald-600 fill-emerald-50" />
            ) : someSelected ? (
              <div className="w-5 h-5 rounded border-2 border-emerald-600 flex items-center justify-center bg-emerald-50">
                <div className="w-2.5 h-1 bg-emerald-600 rounded-xs" />
              </div>
            ) : (
              <Square className="w-5 h-5 text-slate-400 hover:text-slate-600" />
            )}
            <span>
              {isAllSelected
                ? 'إلغاء تحديد الكل'
                : `تحديد جميع الرسائل (${notifications.length})`}
            </span>
          </button>

          {selectedCount > 0 && (
            <span className="text-xs font-semibold text-emerald-800 bg-emerald-100/70 px-2.5 py-0.5 rounded-full">
              تم تحديد {selectedCount} رسالة
            </span>
          )}
        </div>

        {/* Dual Sequential Dispatch Actions */}
        <div className="flex items-center flex-wrap gap-2">
          {/* Batch WhatsApp Button */}
          <button
            onClick={() => onStartBatchSend('whatsapp')}
            type="button"
            className="flex items-center gap-2 px-3.5 py-2 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-xl shadow-xs transition-all active:scale-[0.98] whitespace-nowrap"
            title="إرسال الرسائل المحددة واحدة تلو الأخرى عبر واتساب"
          >
            <MessageSquare className="w-4 h-4" />
            <span>إرسال متتابع عبر واتساب ({selectedCount || notifications.length})</span>
          </button>

          {/* Batch SMS Button */}
          <button
            onClick={() => onStartBatchSend('sms')}
            type="button"
            className="flex items-center gap-2 px-3.5 py-2 text-xs font-bold text-white bg-sky-600 hover:bg-sky-700 rounded-xl shadow-xs transition-all active:scale-[0.98] whitespace-nowrap"
            title="إرسال الرسائل المحددة واحدة تلو الأخرى كرسائل SMS قصيرة"
          >
            <Smartphone className="w-4 h-4" />
            <span>إرسال متتابع عبر SMS ({selectedCount || notifications.length})</span>
          </button>
        </div>
      </div>

      {/* Vertical Feed: Cards Stacked One After Another */}
      <div className="space-y-4">
        {notifications.map((item, idx) => {
          const isSelected = selectedIds.has(item.id);

          return (
            <div
              key={item.id}
              className={`bg-white rounded-2xl border transition-all duration-200 overflow-hidden shadow-xs hover:shadow-md ${
                isSelected
                  ? 'border-emerald-500 ring-2 ring-emerald-500/20 bg-emerald-50/10'
                  : 'border-slate-200/90 hover:border-slate-300'
              }`}
            >
              {/* Card Header */}
              <div className="px-5 py-3.5 bg-slate-50/80 border-b border-slate-100 flex flex-wrap items-center justify-between gap-3">
                {/* Checkbox, Index, and Client */}
                <div className="flex items-center gap-3">
                  <button
                    onClick={() => onToggleSelect(item.id)}
                    type="button"
                    className="text-slate-400 hover:text-emerald-600 transition-colors p-0.5"
                    title={isSelected ? 'إلغاء التحديد' : 'تحديد الرسالة'}
                  >
                    {isSelected ? (
                      <CheckSquare className="w-5 h-5 text-emerald-600 fill-emerald-50" />
                    ) : (
                      <Square className="w-5 h-5 text-slate-300 hover:text-slate-500" />
                    )}
                  </button>

                  <div className="flex items-center gap-2">
                    <span className="text-xs font-mono font-bold text-slate-400 tabular-nums">
                      #{idx + 1}
                    </span>
                    <span className="text-sm font-bold text-slate-900">
                      {item.clientName || 'عميل غير مسجل'}
                    </span>
                  </div>
                </div>

                {/* Right Header: Phone, Balance & Dual Channel Status Indicators */}
                <div className="flex items-center flex-wrap gap-2 text-xs">
                  {/* Total Balance */}
                  {item.totalAccount && (
                    <div className="flex items-center gap-1 font-mono font-bold text-emerald-700 bg-emerald-50 border border-emerald-200/60 px-2.5 py-1 rounded-lg">
                      <DollarSign className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                      <span>{item.totalAccount}</span>
                    </div>
                  )}

                  {/* Phone */}
                  <div
                    className="flex items-center gap-1.5 font-mono text-slate-700 bg-white border border-slate-200 px-2.5 py-1 rounded-lg tabular-nums"
                    dir="ltr"
                  >
                    <Phone className="w-3.5 h-3.5 text-slate-400" />
                    <span className="font-semibold">{item.phoneFull || item.phone}</span>
                  </div>

                  {/* Dual Channel Status Badges (واتساب و SMS) */}
                  <ChannelStatusBadge
                    whatsappSent={item.whatsappSent}
                    smsSent={item.smsSent}
                    onToggleWhatsApp={() => onToggleWhatsAppStatus(item.id)}
                    onToggleSms={() => onToggleSmsStatus(item.id)}
                  />
                </div>
              </div>

              {/* Message Content: Chat Bubble Visual Container */}
              <div className="p-5">
                <div className="bg-[#f0f2f5] p-4 rounded-xl border border-slate-200 relative">
                  <div className="text-[11px] font-semibold text-slate-500 mb-2 flex items-center justify-between">
                    <span className="flex items-center gap-1">
                      <MessageSquare className="w-3.5 h-3.5 text-emerald-600" />
                      نص الإشعار الجاهز للإرسال (مصحح الإيموجي والتنسيق):
                    </span>
                    <span className="font-mono text-slate-400 text-[10px]">
                      {item.movementTime}
                    </span>
                  </div>

                  {/* Simulated Message Bubble */}
                  <div className="bg-white rounded-xl rounded-tr-xs p-4 shadow-xs border border-slate-100/80">
                    <div
                      className="whitespace-pre-wrap text-sm text-slate-800 leading-relaxed font-sans select-text"
                      dir="rtl"
                    >
                      {item.rawMsg}
                    </div>
                  </div>
                </div>
              </div>

              {/* Card Footer: Action Buttons (Individual WhatsApp, Individual SMS, Copy, etc.) */}
              <div className="px-5 py-3.5 bg-slate-50/60 border-t border-slate-100 flex flex-wrap items-center justify-between gap-3">
                <div className="flex items-center gap-2">
                  {/* Copy Message Button */}
                  <button
                    onClick={() => handleCopy(item.rawMsg, `msg-${item.id}`)}
                    type="button"
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 bg-white border border-slate-200 rounded-lg hover:bg-slate-100 transition-colors"
                  >
                    {copiedId === `msg-${item.id}` ? (
                      <>
                        <Check className="w-3.5 h-3.5 text-emerald-600" />
                        <span className="text-emerald-700 font-semibold">تم النسخ!</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5 text-slate-400" />
                        <span>نسخ نص الرسالة</span>
                      </>
                    )}
                  </button>

                  {/* Copy Phone Button */}
                  <button
                    onClick={() => handleCopy(item.phoneFull || item.phone, `ph-${item.id}`)}
                    type="button"
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 bg-white border border-slate-200 rounded-lg hover:bg-slate-100 transition-colors"
                  >
                    {copiedId === `ph-${item.id}` ? (
                      <>
                        <Check className="w-3.5 h-3.5 text-emerald-600" />
                        <span className="text-emerald-700 font-semibold">تم نسخ الرقم!</span>
                      </>
                    ) : (
                      <>
                        <Phone className="w-3.5 h-3.5 text-slate-400" />
                        <span>نسخ الرقم</span>
                      </>
                    )}
                  </button>
                </div>

                {/* Individual Send Actions: Both WhatsApp & SMS */}
                <div className="flex items-center gap-2.5">
                  {/* Individual SMS Button */}
                  <button
                    onClick={() => onSingleSendSms(item)}
                    type="button"
                    className="inline-flex items-center gap-2 px-3.5 py-2 text-xs font-bold text-white bg-sky-600 hover:bg-sky-700 rounded-xl shadow-xs transition-all active:scale-[0.98]"
                    title="فتح وإرسال رسالة نصية قصيرة SMS فوراً"
                  >
                    <Smartphone className="w-3.5 h-3.5" />
                    <span>إرسال فردي SMS</span>
                    {item.smsSent && <Check className="w-3 h-3 text-sky-200" />}
                  </button>

                  {/* Individual WhatsApp Button */}
                  <button
                    onClick={() => onSingleSendWhatsApp(item)}
                    type="button"
                    className="inline-flex items-center gap-2 px-4 py-2 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-xl shadow-xs transition-all active:scale-[0.98]"
                    title="فتح وإرسال هذه الرسالة فردياً عبر واتساب"
                  >
                    <MessageSquare className="w-3.5 h-3.5" />
                    <span>إرسال فردي واتساب</span>
                    <ExternalLink className="w-3 h-3 opacity-75" />
                    {item.whatsappSent && <Check className="w-3 h-3 text-emerald-200" />}
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
