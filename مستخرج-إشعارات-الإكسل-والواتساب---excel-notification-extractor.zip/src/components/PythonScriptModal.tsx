import React, { useState } from 'react';
import { X, Copy, Check, Download, Terminal, Code2 } from 'lucide-react';
import { generatePythonScript, ColumnMapping } from '../utils/excelParser';

interface PythonScriptModalProps {
  isOpen: boolean;
  onClose: () => void;
  fileName: string;
  selectedDate: string;
  mapping: ColumnMapping;
  countryCode: string;
}

export const PythonScriptModal: React.FC<PythonScriptModalProps> = ({
  isOpen,
  onClose,
  fileName,
  selectedDate,
  mapping,
  countryCode,
}) => {
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const scriptCode = generatePythonScript({
    fileName: fileName || 'حنححخه.xlsx',
    targetDate: selectedDate || '2026-09-29',
    phoneCol: mapping.phoneCol || 'المستلم',
    msgCol: mapping.msgCol || 'الرسالة',
    timeCol: mapping.timeCol || 'الوقت',
    defaultCode: countryCode || '967',
  });

  const handleCopy = () => {
    navigator.clipboard.writeText(scriptCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = () => {
    const blob = new Blob([scriptCode], { type: 'text/x-python;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `extract_notifications_${selectedDate || '2026-09-29'}.py`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
      <div className="bg-white rounded-2xl shadow-xl border border-slate-200 w-full max-w-2xl overflow-hidden animate-in fade-in duration-200">
        {/* Header */}
        <div className="px-5 py-4 border-b border-slate-200 bg-slate-50 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-slate-900 text-white flex items-center justify-center">
              <Terminal className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-800">
                كود بايثون الأصلي للتشغيل المستقل (Offline Python Script)
              </h3>
              <p className="text-xs text-slate-500">
                مخصص لملفك الحالي ({fileName || 'بيانات_الإشعارات.xlsx'}) وتاريخ {selectedDate || '2026-09-29'}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-600 p-1.5 rounded-lg hover:bg-slate-200/60 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Code Content */}
        <div className="p-5">
          <div className="relative rounded-xl overflow-hidden border border-slate-800 bg-[#0d1117] text-slate-200">
            <div className="flex items-center justify-between px-4 py-2 bg-[#161b22] border-b border-slate-800 text-[11px] text-slate-400 font-mono">
              <span>extract_notifications.py</span>
              <span>Python 3.8+ (pandas, openpyxl)</span>
            </div>
            <pre className="p-4 text-xs font-mono overflow-x-auto max-h-[380px] leading-relaxed text-slate-100 select-all" dir="ltr">
              <code>{scriptCode}</code>
            </pre>
          </div>

          <div className="mt-3 bg-slate-50 p-3 rounded-lg border border-slate-200 text-xs text-slate-600 space-y-1">
            <div className="font-semibold text-slate-800">متطلبات تشغيل السكربت في جهازك:</div>
            <code className="block font-mono text-[11px] bg-white p-1.5 rounded border border-slate-200 text-slate-700 select-all" dir="ltr">
              pip install pandas openpyxl
            </code>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="px-5 py-3.5 bg-slate-50 border-t border-slate-200 flex items-center justify-between gap-3">
          <button
            onClick={onClose}
            type="button"
            className="px-3.5 py-1.5 text-xs text-slate-600 hover:text-slate-800 font-medium"
          >
            إغلاق
          </button>

          <div className="flex items-center gap-2">
            <button
              onClick={handleCopy}
              type="button"
              className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-100 transition-colors"
            >
              {copied ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-600" />
                  <span className="text-emerald-700 font-semibold">تم النسخ</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5 text-slate-500" />
                  <span>نسخ الكود</span>
                </>
              )}
            </button>

            <button
              onClick={handleDownload}
              type="button"
              className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-lg transition-colors"
            >
              <Download className="w-3.5 h-3.5" />
              <span>تحميل ملف .py</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
