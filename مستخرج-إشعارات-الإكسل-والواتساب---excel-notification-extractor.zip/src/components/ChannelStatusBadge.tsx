import React from 'react';
import { MessageSquare, Smartphone, Check, Clock } from 'lucide-react';

interface ChannelStatusBadgeProps {
  whatsappSent: boolean;
  smsSent: boolean;
  onToggleWhatsApp?: () => void;
  onToggleSms?: () => void;
  size?: 'sm' | 'md';
}

export const ChannelStatusBadge: React.FC<ChannelStatusBadgeProps> = ({
  whatsappSent,
  smsSent,
  onToggleWhatsApp,
  onToggleSms,
  size = 'md',
}) => {
  const isSm = size === 'sm';

  return (
    <div className="flex items-center gap-1.5 flex-wrap">
      {/* WhatsApp Status Indicator */}
      <button
        type="button"
        onClick={onToggleWhatsApp}
        className={`inline-flex items-center gap-1 rounded-md font-medium transition-all ${
          isSm ? 'px-2 py-0.5 text-[10px]' : 'px-2.5 py-1 text-xs'
        } ${
          whatsappSent
            ? 'bg-emerald-100 text-emerald-800 border border-emerald-300 font-semibold shadow-2xs hover:bg-emerald-200'
            : 'bg-slate-100 text-slate-400 border border-slate-200 hover:bg-slate-200/70 hover:text-slate-600'
        }`}
        title={`واتساب: ${whatsappSent ? 'تم الإرسال (انقر لتغيير الحالة)' : 'لم يُرسل (انقر لتحديده كمرسل)'}`}
      >
        <MessageSquare className={isSm ? 'w-3 h-3' : 'w-3.5 h-3.5'} />
        <span>واتساب</span>
        {whatsappSent ? (
          <Check className={`${isSm ? 'w-3 h-3' : 'w-3.5 h-3.5'} text-emerald-700`} />
        ) : (
          <span className="text-[10px] text-slate-400 font-mono">✕</span>
        )}
      </button>

      {/* SMS Status Indicator */}
      <button
        type="button"
        onClick={onToggleSms}
        className={`inline-flex items-center gap-1 rounded-md font-medium transition-all ${
          isSm ? 'px-2 py-0.5 text-[10px]' : 'px-2.5 py-1 text-xs'
        } ${
          smsSent
            ? 'bg-sky-100 text-sky-800 border border-sky-300 font-semibold shadow-2xs hover:bg-sky-200'
            : 'bg-slate-100 text-slate-400 border border-slate-200 hover:bg-slate-200/70 hover:text-slate-600'
        }`}
        title={`SMS: ${smsSent ? 'تم الإرسال (انقر لتغيير الحالة)' : 'لم يُرسل (انقر لتحديده كمرسل)'}`}
      >
        <Smartphone className={isSm ? 'w-3 h-3' : 'w-3.5 h-3.5'} />
        <span>SMS</span>
        {smsSent ? (
          <Check className={`${isSm ? 'w-3 h-3' : 'w-3.5 h-3.5'} text-sky-700`} />
        ) : (
          <span className="text-[10px] text-slate-400 font-mono">✕</span>
        )}
      </button>
    </div>
  );
};
