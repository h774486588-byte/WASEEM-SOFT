import { clearAccessToken } from './googleAuth';

export interface DriveFileItem {
  id: string;
  name: string;
  mimeType: string;
  modifiedTime: string;
  size?: string;
  iconLink?: string;
}

/**
 * Searches and lists Excel & Spreadsheet files from Google Drive
 */
export async function listDriveFiles(
  accessToken: string,
  query: string = ''
): Promise<DriveFileItem[]> {
  // Filter for spreadsheets (.xlsx, .xls, .csv, google sheets) and not trashed
  let q = "trashed = false and (mimeType = 'application/vnd.google-apps.spreadsheet' or mimeType = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' or mimeType = 'application/vnd.ms-excel' or mimeType = 'text/csv' or name contains '.xlsx' or name contains '.xls' or name contains '.csv')";

  if (query.trim()) {
    const escaped = query.replace(/'/g, "\\'");
    q = `(${q}) and (name contains '${escaped}')`;
  }

  const url = new URL('https://www.googleapis.com/drive/v3/files');
  url.searchParams.set('q', q);
  url.searchParams.set('fields', 'files(id, name, mimeType, modifiedTime, size, iconLink)');
  url.searchParams.set('orderBy', 'modifiedTime desc');
  url.searchParams.set('pageSize', '30');

  const res = await fetch(url.toString(), {
    headers: {
      Authorization: `Bearer ${accessToken}`,
    },
  });

  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    const rawMsg = err.error?.message || '';

    if (
      res.status === 401 ||
      res.status === 403 ||
      rawMsg.toLowerCase().includes('insufficient authentication scopes')
    ) {
      clearAccessToken();
      throw new Error(
        'لم يتم منح صلاحية الوصول إلى ملفات Google Drive في الجلسة السابقة. يرجى الضغط على "تسجيل الدخول باستخدام Google" والتأكد من تحديد خيار الوصول للملفات.'
      );
    }

    throw new Error(rawMsg || `فشل قراءة الملفات من Google Drive (${res.status})`);
  }

  const data = await res.json();
  return data.files || [];
}

/**
 * Downloads file binary buffer from Google Drive
 */
export async function downloadDriveFile(
  fileId: string,
  mimeType: string,
  accessToken: string | null
): Promise<{ buffer: ArrayBuffer; modifiedTime: string; name: string }> {
  const headers: Record<string, string> = {};
  if (accessToken) {
    headers['Authorization'] = `Bearer ${accessToken}`;
  }

  // 1. Get latest file metadata first
  let modifiedTime = new Date().toISOString();
  let name = 'ملف_Google_Drive.xlsx';

  if (accessToken) {
    try {
      const metaRes = await fetch(
        `https://www.googleapis.com/drive/v3/files/${fileId}?fields=id,name,mimeType,modifiedTime,size`,
        { headers }
      );
      if (metaRes.ok) {
        const meta = await metaRes.json();
        modifiedTime = meta.modifiedTime || modifiedTime;
        name = meta.name || name;
      }
    } catch {
      // Continue to download if metadata fetch fails
    }
  }

  // 2. Fetch content
  let downloadUrl = `https://www.googleapis.com/drive/v3/files/${fileId}?alt=media`;
  if (mimeType.includes('spreadsheet') || mimeType.includes('google-apps')) {
    // Export Google Sheet as Excel XLSX
    downloadUrl = `https://docs.google.com/spreadsheets/d/${fileId}/export?format=xlsx`;
  }

  const contentRes = await fetch(downloadUrl, { headers });

  if (!contentRes.ok) {
    // If authenticated download fails and it's a sheet, try public export fallback
    if (downloadUrl.includes('drive/v3/files')) {
      const fallbackUrl = `https://docs.google.com/spreadsheets/d/${fileId}/export?format=xlsx`;
      const fallbackRes = await fetch(fallbackUrl);
      if (fallbackRes.ok) {
        const buffer = await fallbackRes.arrayBuffer();
        return { buffer, modifiedTime, name };
      }
    }

    if (contentRes.status === 401 || contentRes.status === 403) {
      clearAccessToken();
      throw new Error('يرجى إعادة تسجيل الدخول لتحديث صلاحية الوصول إلى ملف Google Drive');
    }

    throw new Error(`تعذر تنزيل محتوى الملف من Google Drive (${contentRes.status})`);
  }

  const buffer = await contentRes.arrayBuffer();
  return { buffer, modifiedTime, name };
}

/**
 * Checks metadata of a file to detect if it has been updated
 */
export async function checkDriveFileMeta(
  fileId: string,
  accessToken: string | null
): Promise<{ modifiedTime: string; name: string; size?: string }> {
  if (!accessToken) {
    return { modifiedTime: new Date().toISOString(), name: '' };
  }

  const res = await fetch(
    `https://www.googleapis.com/drive/v3/files/${fileId}?fields=id,name,modifiedTime,size`,
    {
      headers: { Authorization: `Bearer ${accessToken}` },
    }
  );

  if (!res.ok) {
    if (res.status === 401 || res.status === 403) {
      clearAccessToken();
    }
    throw new Error('فشل التحقق من تحديث الملف على Google Drive');
  }

  const meta = await res.json();
  return {
    modifiedTime: meta.modifiedTime || '',
    name: meta.name || '',
    size: meta.size,
  };
}

/**
 * Play a gentle alert chime when new notifications are detected
 */
export function playNotificationChime() {
  try {
    const AudioContext = window.AudioContext || (window as any).webkitAudioContext;
    if (!AudioContext) return;
    const ctx = new AudioContext();

    const now = ctx.currentTime;
    // Pleasant two-tone chime (880Hz then 1320Hz)
    const osc1 = ctx.createOscillator();
    const gain1 = ctx.createGain();
    osc1.type = 'sine';
    osc1.frequency.setValueAtTime(880, now);
    gain1.gain.setValueAtTime(0.15, now);
    gain1.gain.exponentialRampToValueAtTime(0.001, now + 0.35);
    osc1.connect(gain1);
    gain1.connect(ctx.destination);
    osc1.start(now);
    osc1.stop(now + 0.35);

    const osc2 = ctx.createOscillator();
    const gain2 = ctx.createGain();
    osc2.type = 'sine';
    osc2.frequency.setValueAtTime(1320, now + 0.12);
    gain2.gain.setValueAtTime(0.18, now + 0.12);
    gain2.gain.exponentialRampToValueAtTime(0.001, now + 0.55);
    osc2.connect(gain2);
    gain2.connect(ctx.destination);
    osc2.start(now + 0.12);
    osc2.stop(now + 0.55);
  } catch {
    // Audio context may be restricted before user gesture
  }
}
