import { initializeApp, getApps, getApp } from 'firebase/app';
import {
  getAuth,
  onAuthStateChanged,
  signOut,
} from 'firebase/auth';
import firebaseConfig from '../../firebase-applet-config.json';

export interface AuthUser {
  displayName: string | null;
  email: string | null;
  photoURL: string | null;
}

// Initialize Firebase App singleton
const app = getApps().length > 0 ? getApp() : initializeApp(firebaseConfig);
export const auth = getAuth(app);

export const DRIVE_SCOPE = 'https://www.googleapis.com/auth/drive.readonly';
export const SCOPES = `https://www.googleapis.com/auth/drive.readonly email profile openid`;

let isSigningIn = false;
let cachedAccessToken: string | null = null;
let cachedUser: AuthUser | null = null;
let authSuccessCallback: ((user: AuthUser, token: string) => void) | null = null;

let tokenClient: any = null;
let pendingResolve: ((val: { user: AuthUser; accessToken: string }) => void) | null = null;
let pendingReject: ((err: any) => void) | null = null;

/**
 * Initialize Google Identity Services (GIS) token client.
 * Pre-initializing guarantees that requestAccessToken() runs synchronously on user click,
 * preventing browser popup blockers from blocking the window.
 */
export function initializeGisClient() {
  if (typeof window === 'undefined') return;
  const google = (window as any).google;
  if (!google?.accounts?.oauth2) return;

  try {
    tokenClient = google.accounts.oauth2.initTokenClient({
      client_id: firebaseConfig.oAuthClientId,
      scope: SCOPES,
      callback: async (tokenResponse: any) => {
        isSigningIn = false;
        if (tokenResponse.error) {
          const msg = tokenResponse.error_description || tokenResponse.error;
          if (pendingReject) {
            pendingReject(new Error(msg));
            pendingReject = null;
            pendingResolve = null;
          }
          return;
        }

        const token = tokenResponse.access_token;
        if (!token) {
          if (pendingReject) {
            pendingReject(new Error('لم يتم استلام تصريح الدخول من Google'));
            pendingReject = null;
            pendingResolve = null;
          }
          return;
        }

        // Validate that user consented to Google Drive scope
        if (google?.accounts?.oauth2?.hasGrantedAllScopes) {
          const hasDriveScope = google.accounts.oauth2.hasGrantedAllScopes(
            tokenResponse,
            DRIVE_SCOPE
          );
          if (!hasDriveScope) {
            if (pendingReject) {
              pendingReject(
                new Error(
                  'لم يتم تفعيل صلاحية Google Drive. يرجى إعادة المحاولة ووضع علامة (✓) بجانب "الاطلاع على جميع ملفاتك في Google Drive وتنزيلها".'
                )
              );
              pendingReject = null;
              pendingResolve = null;
            }
            return;
          }
        }

        cachedAccessToken = token;

        // Fetch user profile info
        let profile: AuthUser = {
          displayName: 'مستخدم Google',
          email: null,
          photoURL: null,
        };

        try {
          const res = await fetch('https://www.googleapis.com/oauth2/v3/userinfo', {
            headers: { Authorization: `Bearer ${token}` },
          });
          if (res.ok) {
            const info = await res.json();
            profile = {
              displayName: info.name || info.email || 'مستخدم Google',
              email: info.email || null,
              photoURL: info.picture || null,
            };
          }
        } catch {
          // ignore profile fetch errors
        }

        cachedUser = profile;
        if (authSuccessCallback) {
          authSuccessCallback(profile, token);
        }

        if (pendingResolve) {
          pendingResolve({ user: profile, accessToken: token });
          pendingResolve = null;
          pendingReject = null;
        }
      },
      error_callback: (err: any) => {
        isSigningIn = false;
        console.error('GIS Error Callback:', err);
        if (pendingReject) {
          const isBlocked =
            err?.type === 'popup_blocked' ||
            err?.message?.toLowerCase().includes('popup') ||
            err?.type?.toLowerCase().includes('popup');

          const friendlyMsg = isBlocked
            ? 'قام المتصفح بحظر النافذة المنبثقة. يرجى الضغط على أيقونة النوافذ المنبثقة في شريط عنوان المتصفح واختيار "السماح دائماً" ثم النقر مجدداً.'
            : err?.message || 'تعذر فتح نافذة تسجيل الدخول من Google';

          pendingReject(new Error(friendlyMsg));
          pendingReject = null;
          pendingResolve = null;
        }
      },
    });
  } catch (e) {
    console.error('Failed to initialize GIS client:', e);
  }
}

// Auto-initialize GIS as soon as DOM is ready
if (typeof window !== 'undefined') {
  if (document.readyState === 'complete') {
    initializeGisClient();
  } else {
    window.addEventListener('load', initializeGisClient);
  }
}

export const initAuth = (
  onAuthSuccess?: (user: AuthUser, token: string) => void,
  onAuthFailure?: () => void
) => {
  if (onAuthSuccess) authSuccessCallback = onAuthSuccess;

  // Attempt to initialize GIS
  initializeGisClient();

  return onAuthStateChanged(auth, async (user) => {
    if (user) {
      cachedUser = {
        displayName: user.displayName,
        email: user.email,
        photoURL: user.photoURL,
      };
      if (cachedAccessToken) {
        if (onAuthSuccess) onAuthSuccess(cachedUser, cachedAccessToken);
      } else if (!isSigningIn) {
        if (onAuthFailure) onAuthFailure();
      }
    } else if (!cachedUser) {
      cachedAccessToken = null;
      if (onAuthFailure) onAuthFailure();
    }
  });
};

/**
 * Direct synchronous sign-in invocation with prompt: 'consent'.
 * Using prompt: 'consent' forces Google to show the Drive permission checkbox,
 * preventing 'Request had insufficient authentication scopes' when an older token exists!
 */
export const googleSignIn = (): Promise<{ user: AuthUser; accessToken: string }> => {
  return new Promise((resolve, reject) => {
    isSigningIn = true;
    pendingResolve = resolve;
    pendingReject = reject;

    const google = (window as any).google;

    if (!tokenClient && google?.accounts?.oauth2) {
      initializeGisClient();
    }

    if (tokenClient) {
      try {
        // Force consent prompt so the Google Drive permissions checkbox is always shown & granted!
        tokenClient.requestAccessToken({ prompt: 'consent' });
      } catch (err: any) {
        isSigningIn = false;
        reject(new Error(err.message || 'فشل فتح نافذة تسجيل الدخول'));
      }
    } else {
      // GIS script wasn't loaded yet -> load it and request
      const script = document.createElement('script');
      script.src = 'https://accounts.google.com/gsi/client';
      script.async = true;
      script.onload = () => {
        initializeGisClient();
        if (tokenClient) {
          tokenClient.requestAccessToken({ prompt: 'consent' });
        } else {
          isSigningIn = false;
          reject(new Error('تعذر تهيئة مكتبة تسجيل الدخول من Google'));
        }
      };
      script.onerror = () => {
        isSigningIn = false;
        reject(new Error('فشل تحميل مكتبة تسجيل الدخول من Google'));
      };
      document.head.appendChild(script);
    }
  });
};

export const getAccessToken = async (): Promise<string | null> => {
  return cachedAccessToken;
};

export const clearAccessToken = () => {
  cachedAccessToken = null;
};

export const logout = async () => {
  try {
    await signOut(auth);
  } catch {
    // ignore
  }
  cachedAccessToken = null;
  cachedUser = null;
};
