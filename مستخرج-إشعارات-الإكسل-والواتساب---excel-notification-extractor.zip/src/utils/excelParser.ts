import * as XLSX from 'xlsx';

export interface ColumnMapping {
  phoneCol: string;
  msgCol: string;
  timeCol: string;
}

export interface ProcessedNotification {
  id: string;
  index: number;
  phone: string;
  phoneFull: string;
  clientName: string;
  movementTime: string;
  targetDate: string;
  totalAccount: string;
  rawMsg: string;
  waLink: string;
  smsLink: string;
  whatsappSent: boolean;
  smsSent: boolean;
  status: 'unsent' | 'sent' | 'skipped';
  originalRow: Record<string, any>;
}

/**
 * Fix Excel XML surrogate encoded emojis
 * (e.g. _xD83D__xDCB0_ -> 💰, _x2705_ -> ✅, etc.)
 */
export function fixExcelSurrogateEmojis(text: any): string {
  if (text === null || text === undefined) return '';
  const str = String(text);

  // 1. Surrogate pairs: _xHHHH__xHHHH_
  const fixedSurrogates = str.replace(
    /_x([0-9A-Fa-f]{4})__x([0-9A-Fa-f]{4})_/g,
    (_, hiHex, loHex) => {
      try {
        const hi = parseInt(hiHex, 16);
        const lo = parseInt(loHex, 16);
        const codePoint = 0x10000 + ((hi - 0xd800) << 10) + (lo - 0xdc00);
        return String.fromCodePoint(codePoint);
      } catch {
        return _;
      }
    }
  );

  // 2. Single BMP entities: _xHHHH_
  return fixedSurrogates.replace(/_x([0-9A-Fa-f]{4})_/g, (_, hex) => {
    try {
      const code = parseInt(hex, 16);
      return String.fromCharCode(code);
    } catch {
      return _;
    }
  });
}

/**
 * Normalizes phone numbers:
 * - strips decimals (e.g. 771234567.0 -> 771234567)
 * - removes spaces, hyphens, and leading plus or zeros
 * - appends country code (default 967 for Yemen if 9 digits and not starting with 967)
 */
export function normalizePhone(raw: any, defaultCountryCode = '967'): { phone: string; phoneFull: string } {
  if (raw === null || raw === undefined) {
    return { phone: '', phoneFull: '' };
  }

  // Convert to string and handle floats (771234567.0)
  let phone = String(raw).trim().split('.')[0];
  
  // Remove non-digit characters except maybe leading +
  phone = phone.replace(/[^\d+]/g, '');
  if (phone.startsWith('+')) {
    phone = phone.substring(1);
  }
  if (phone.startsWith('00')) {
    phone = phone.substring(2);
  }

  let phoneFull = phone;
  // If 9 digits (standard Yemeni mobile like 77xxxxxxx, 73xxxxxxx, 71xxxxxxx, 70xxxxxxx)
  if (phone.length === 9 && !phone.startsWith(defaultCountryCode)) {
    phoneFull = defaultCountryCode + phone;
  } else if (phone.length === 10 && phone.startsWith('0')) {
    // e.g. 0771234567 -> 967771234567
    phone = phone.substring(1);
    phoneFull = defaultCountryCode + phone;
  }

  return { phone, phoneFull };
}

/**
 * Parses diverse Excel date/time representations to YYYY-MM-DD
 */
export function parseExcelDateTime(val: any): { dateStr: string; timeStr: string; rawStr: string } {
  if (val === null || val === undefined || val === '') {
    return { dateStr: '', timeStr: '', rawStr: '' };
  }

  const rawStr = String(val).trim();

  // If already a JS Date
  if (val instanceof Date && !isNaN(val.getTime())) {
    const y = val.getFullYear();
    const m = String(val.getMonth() + 1).padStart(2, '0');
    const d = String(val.getDate()).padStart(2, '0');
    const hh = String(val.getHours()).padStart(2, '0');
    const mm = String(val.getMinutes()).padStart(2, '0');
    const ss = String(val.getSeconds()).padStart(2, '0');
    return {
      dateStr: `${y}-${m}-${d}`,
      timeStr: `${y}-${m}-${d} ${hh}:${mm}:${ss}`,
      rawStr,
    };
  }

  // If numeric (Excel serial date number, e.g. 46294.52)
  if (typeof val === 'number' || (!isNaN(Number(val)) && !rawStr.includes('-') && !rawStr.includes('/'))) {
    const num = Number(val);
    if (num > 30000 && num < 70000) {
      try {
        const parsed = XLSX.SSF.parse_date_code(num);
        if (parsed) {
          const y = parsed.y;
          const m = String(parsed.m).padStart(2, '0');
          const d = String(parsed.d).padStart(2, '0');
          const hh = String(parsed.H || 0).padStart(2, '0');
          const mm = String(parsed.M || 0).padStart(2, '0');
          const ss = String(Math.floor(parsed.S || 0)).padStart(2, '0');
          return {
            dateStr: `${y}-${m}-${d}`,
            timeStr: `${y}-${m}-${d} ${hh}:${mm}:${ss}`,
            rawStr,
          };
        }
      } catch {
        // fallback
      }
    }
  }

  // Match YYYY-MM-DD or YYYY/MM/DD
  const ymdMatch = rawStr.match(/(\d{4})[-/.](\d{1,2})[-/.](\d{1,2})/);
  if (ymdMatch) {
    const y = ymdMatch[1];
    const m = ymdMatch[2].padStart(2, '0');
    const d = ymdMatch[3].padStart(2, '0');
    return {
      dateStr: `${y}-${m}-${d}`,
      timeStr: rawStr,
      rawStr,
    };
  }

  // Match DD-MM-YYYY or DD/MM/YYYY
  const dmyMatch = rawStr.match(/(\d{1,2})[-/.](\d{1,2})[-/.](\d{4})/);
  if (dmyMatch) {
    const d = dmyMatch[1].padStart(2, '0');
    const m = dmyMatch[2].padStart(2, '0');
    const y = dmyMatch[3];
    return {
      dateStr: `${y}-${m}-${d}`,
      timeStr: rawStr,
      rawStr,
    };
  }

  // Native Date fallback
  const dObj = new Date(rawStr);
  if (!isNaN(dObj.getTime())) {
    const y = dObj.getFullYear();
    const m = String(dObj.getMonth() + 1).padStart(2, '0');
    const d = String(dObj.getDate()).padStart(2, '0');
    return {
      dateStr: `${y}-${m}-${d}`,
      timeStr: rawStr,
      rawStr,
    };
  }

  return { dateStr: '', timeStr: rawStr, rawStr };
}

/**
 * Extracts notification details from a row
 */
export function extractRowNotification(
  row: Record<string, any>,
  index: number,
  mapping: ColumnMapping,
  defaultCountryCode = '967'
): ProcessedNotification {
  const rawMsgVal = row[mapping.msgCol] !== undefined ? row[mapping.msgCol] : '';
  const rawMsg = fixExcelSurrogateEmojis(rawMsgVal);

  const phoneVal = row[mapping.phoneCol];
  const { phone, phoneFull } = normalizePhone(phoneVal, defaultCountryCode);

  const timeVal = row[mapping.timeCol];
  const parsedTime = parseExcelDateTime(timeVal);

  // Fallback: If date was not found in the time column, check if date is mentioned inside the message text
  if (!parsedTime.dateStr && typeof rawMsg === 'string') {
    const msgDateMatch = rawMsg.match(/(\d{4})[-/.](\d{1,2})[-/.](\d{1,2})/);
    if (msgDateMatch) {
      const y = msgDateMatch[1];
      const m = msgDateMatch[2].padStart(2, '0');
      const d = msgDateMatch[3].padStart(2, '0');
      parsedTime.dateStr = `${y}-${m}-${d}`;
    }
  }

  // Extract client name using: العميل:\s*(.*?)(?=\n|$)
  let clientName = '';
  const clientMatch = rawMsg.match(/العميل:\s*(.*?)(?=\n|$)/);
  if (clientMatch) {
    clientName = clientMatch[1].trim();
  } else {
    // Alternate patterns: المستفيد: or السيد/السيدة:
    const altClient = rawMsg.match(/(?:المستفيد|السيد|الزبون|اسم العميل):\s*(.*?)(?=\n|$)/);
    if (altClient) clientName = altClient[1].trim();
  }

  // Extract total balance using: إجمالي الحساب:\s*(.*?)(?=\n|$)
  let totalAccount = '';
  const balMatch = rawMsg.match(/إجمالي الحساب:\s*(.*?)(?=\n|$)/);
  if (balMatch) {
    totalAccount = balMatch[1].trim();
  } else {
    // Alternate balance patterns: الرصيد: or الرصيد المتبقي: or الرصيد الحالي:
    const altBal = rawMsg.match(/(?:الرصيد المتبقي|الرصيد الحالي|الرصيد|المبلغ الإجمالي):\s*(.*?)(?=\n|$)/);
    if (altBal) totalAccount = altBal[1].trim();
  }

  // WhatsApp Link: https://wa.me/{phone_full}?text={quote(raw_msg)}
  const waLink = phoneFull ? `https://wa.me/${phoneFull}?text=${encodeURIComponent(rawMsg)}` : '';

  // SMS Link: sms:{phone_full}?body={quote(raw_msg)}
  const smsLink = phoneFull ? `sms:${phoneFull}?body=${encodeURIComponent(rawMsg)}` : '';

  // Stable deterministic ID
  const id = `notif-${index}-${phoneFull}-${parsedTime.dateStr || 'nodate'}`;

  return {
    id,
    index: index + 1,
    phone,
    phoneFull,
    clientName,
    movementTime: parsedTime.timeStr || String(timeVal || ''),
    targetDate: parsedTime.dateStr,
    totalAccount,
    rawMsg,
    waLink,
    smsLink,
    whatsappSent: false,
    smsSent: false,
    status: 'unsent',
    originalRow: row,
  };
}

/**
 * Deduplicate notifications to prevent duplicate messages
 * criteria: 'phone_and_msg' (default, drops same phone + identical message)
 * or 'phone_only' (at most 1 message per phone number on that date)
 */
export function deduplicateNotifications(
  items: ProcessedNotification[],
  criteria: 'phone_and_msg' | 'phone_only' = 'phone_and_msg'
): { unique: ProcessedNotification[]; duplicateCount: number } {
  const seen = new Set<string>();
  const unique: ProcessedNotification[] = [];
  let duplicateCount = 0;

  for (const item of items) {
    // Normalize message whitespace for reliable comparison
    const normMsg = item.rawMsg.replace(/\s+/g, ' ').trim();
    const key =
      criteria === 'phone_and_msg'
        ? `${item.phoneFull}___${normMsg}`
        : item.phoneFull;

    if (seen.has(key)) {
      duplicateCount++;
    } else {
      seen.add(key);
      unique.push(item);
    }
  }

  return { unique, duplicateCount };
}

/**
 * Auto-detect column headers for phone, message, and time
 */
export function detectColumns(headers: string[]): ColumnMapping {
  let phoneCol = '';
  let msgCol = '';
  let timeCol = '';

  for (const h of headers) {
    const clean = h.trim();
    const lower = clean.toLowerCase();

    // Phone candidate
    if (!phoneCol) {
      if (
        clean === 'المستلم' ||
        clean.includes('مستلم') ||
        clean.includes('هاتف') ||
        clean.includes('جوال') ||
        clean.includes('موبايل') ||
        lower.includes('phone') ||
        lower.includes('recipient') ||
        lower.includes('mobile')
      ) {
        phoneCol = clean;
      }
    }

    // Message candidate
    if (!msgCol) {
      if (
        clean === 'الرسالة' ||
        clean.includes('رسالة') ||
        clean.includes('بيان') ||
        clean.includes('نص') ||
        clean.includes('إشعار') ||
        lower.includes('message') ||
        lower.includes('msg') ||
        lower.includes('text') ||
        lower.includes('body')
      ) {
        msgCol = clean;
      }
    }

    // Time candidate
    if (!timeCol) {
      if (
        clean === 'الوقت' ||
        clean.includes('وقت') ||
        clean.includes('تاريخ') ||
        lower.includes('time') ||
        lower.includes('date') ||
        lower.includes('created')
      ) {
        timeCol = clean;
      }
    }
  }

  // Fallback defaults if not detected
  if (!phoneCol && headers.length > 0) phoneCol = headers[0];
  if (!msgCol && headers.length > 1) msgCol = headers[1];
  if (!timeCol && headers.length > 2) timeCol = headers[2];

  return { phoneCol, msgCol, timeCol };
}

/**
 * Export processed rows to styled Excel file
 */
export function exportToExcel(
  items: ProcessedNotification[],
  targetDateStr: string = ''
) {
  const exportData = items.map((item) => ({
    'رقم الهاتف': item.phone,
    'رقم الهاتف الدولي': item.phoneFull,
    'اسم العميل': item.clientName,
    'وقت الحركة': item.movementTime,
    'إجمالي الحساب': item.totalAccount,
    'نص الإشعار': item.rawMsg,
    'رابط واتساب': item.waLink,
  }));

  const worksheet = XLSX.utils.json_to_sheet(exportData);

  // Set column widths
  worksheet['!cols'] = [
    { wch: 16 }, // phone
    { wch: 18 }, // phone full
    { wch: 25 }, // client name
    { wch: 22 }, // movement time
    { wch: 22 }, // total account
    { wch: 55 }, // message
    { wch: 45 }, // wa link
  ];

  // Set RTL direction on worksheet view
  (worksheet as any)['!views'] = [{ rightToLeft: true }];

  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, 'الإشعارات');

  const filename = targetDateStr ? `اشعارات_${targetDateStr}.xlsx` : `اشعارات_مستخرجة_${new Date().toISOString().slice(0, 10)}.xlsx`;
  XLSX.writeFile(workbook, filename);
}

/**
 * Export to CSV format
 */
export function exportToCsv(items: ProcessedNotification[], targetDateStr: string = '') {
  const exportData = items.map((item) => ({
    'رقم الهاتف': item.phone,
    'اسم العميل': item.clientName,
    'وقت الحركة': item.movementTime,
    'إجمالي الحساب': item.totalAccount,
    'نص الإشعار': item.rawMsg,
    'رابط واتساب': item.waLink,
  }));

  const worksheet = XLSX.utils.json_to_sheet(exportData);
  const csv = XLSX.utils.sheet_to_csv(worksheet);
  const blob = new Blob(['\uFEFF' + csv], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = targetDateStr ? `اشعارات_${targetDateStr}.csv` : `اشعارات.csv`;
  a.click();
  URL.revokeObjectURL(url);
}

/**
 * Generate Python script matching user's original script
 */
export function generatePythonScript(params: {
  fileName?: string;
  targetDate?: string;
  phoneCol?: string;
  msgCol?: string;
  timeCol?: string;
  defaultCode?: string;
}): string {
  const fName = params.fileName || 'بيانات_الإشعارات.xlsx';
  const tDate = params.targetDate || '2026-09-29';
  const phoneCol = params.phoneCol || 'المستلم';
  const msgCol = params.msgCol || 'الرسالة';
  const timeCol = params.timeCol || 'الوقت';
  const code = params.defaultCode || '967';

  return `import pandas as pd
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter
import re
from urllib.parse import quote

def extract_notifications_by_date(file_path, target_date_str):
    """
    file_path: مسار ملف الإكسل (مثال: '${fName}')
    target_date_str: التاريخ المطلوب بصيغة 'YYYY-MM-DD' (مثال: '${tDate}')
    """
    print(f"جاري قراءة الملف: {file_path} ...")
    df = pd.read_excel(file_path)
    
    # تحويل وقت الحركة إلى تاريخ
    df['الوقت_dt'] = pd.to_datetime(df['${timeCol}'], errors='coerce')
    df['تاريخ_اليوم'] = df['الوقت_dt'].dt.strftime('%Y-%m-%d')
    
    # الفلترة الحصرية حسب التاريخ المحدد فقط
    df_filtered = df[df['تاريخ_اليوم'] == target_date_str].copy()
    
    if df_filtered.empty:
        print(f"لا توجد إشعارات مسجلة لتاريخ: {target_date_str}")
        return

    # منع التكرار: استبعاد الإشعارات المكررة لنفس رقم الهاتف ونفس الرسالة
    initial_count = len(df_filtered)
    df_filtered = df_filtered.drop_duplicates(subset=['${phoneCol}', '${msgCol}']).copy()
    duplicates_removed = initial_count - len(df_filtered)
    if duplicates_removed > 0:
        print(f"تم منع التكرار: تم استبعاد {duplicates_removed} إشعار مكرر بنجاح.")
    
    # تصحيح ترميز Emojis من الملف
    def fix_emojis(text):
        if not isinstance(text, str): return text
        def replace_surrogates(m):
            hi, lo = int(m.group(1), 16), int(m.group(2), 16)
            return chr(0x10000 + ((hi - 0xD800) << 10) + (lo - 0xDC00))
        fixed = re.sub(r'_x([0-9A-Fa-f]{4})__x([0-9A-Fa-f]{4})_', replace_surrogates, text)
        return re.sub(r'_x([0-9A-Fa-f]{4})_', lambda m: chr(int(m.group(1), 16)), fixed)

    # تجهيز الصفوف
    processed = []
    for idx, row in df_filtered.iterrows():
        raw_msg = fix_emojis(row['${msgCol}'])
        phone = str(row['${phoneCol}']).strip().split('.')[0]
        phone_full = "${code}" + phone if len(phone) == 9 and not phone.startswith("${code}") else phone
        
        c_name = re.search(r'العميل:\\s*(.*?)(?=\\n|$)', raw_msg)
        bal = re.search(r'إجمالي الحساب:\\s*(.*?)(?=\\n|$)', raw_msg)
        
        wa_link = f"https://wa.me/{phone_full}?text={quote(raw_msg)}"
        
        processed.append({
            'رقم الهاتف': phone,
            'اسم العميل': c_name.group(1).strip() if c_name else "",
            'وقت الحركة': str(row['${timeCol}']),
            'إجمالي الحساب': bal.group(1).strip() if bal else "",
            'نص الإشعار': raw_msg,
            'رابط واتساب': wa_link
        })
        
    res_df = pd.DataFrame(processed)
    
    # تصدير الملف وتنسيقه
    output_filename = f"اشعارات_{target_date_str}.xlsx"
    res_df.to_excel(output_filename, index=False)
    print(f"تم استخراج {len(res_df)} إشعار وحفظها بنجاح في {output_filename}")

# تشغيل الدالة للتجربة:
extract_notifications_by_date('${fName}', '${tDate}')
`;
}
